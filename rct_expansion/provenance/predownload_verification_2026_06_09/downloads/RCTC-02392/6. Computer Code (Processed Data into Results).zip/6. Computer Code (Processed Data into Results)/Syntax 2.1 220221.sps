﻿* Encoding: UTF-8.
* Encoding: .
* Encoding: .
* Encoding: .
* Encoding: .
* Encoding: .

************************* Variable creations****************************************

*to give all PPN an ID

DATASET ACTIVATE DataSet1.
COMPUTE ID=$CASENUM.
EXECUTE.

*recoding for incentive and feedback frame factors

DATASET ACTIVATE DataSet1.
RECODE @$groupNo (3=2) (5=2) (2=1) (4=1) INTO Incentive_type.
VARIABLE LABELS  Incentive_type 'Incentive_type'.
EXECUTE.

VALUE LABELS
Incentive_type
1 'Reward'
2 'Deposit'.
EXECUTE.

RECODE @$groupNo (3=1) (2=1) (4=2) (5=2) INTO Feedback_frame.
VARIABLE LABELS  Feedback_frame 'Feedback_frame'.
EXECUTE.

VALUE LABELS
Feedback_frame
1 'Gain frame'
2 'Loss frame'.
EXECUTE.

*to have the group labels clear

AUTORECODE VARIABLES=Group 
  /INTO Groups
  /PRINT.

VALUE LABELS
Groups
1 'control'
2 'Reward/Gain'
3 'Deposit/Gain'
4 'Reward/Loss'
5 'Deposit/Loss'.  
EXECUTE.

DATASET ACTIVATE DataSet1.
AUTORECODE VARIABLES=Whatgenderdoyouidentifywith  
  /INTO Gender
  /PRINT.

RECODE Gender (1=SYSMIS).
EXECUTE.

AUTORECODE VARIABLES=WhatisyourNationality  Inwhichcountrydoyoucurrentlylive 
    DoyoucurrentlystudyatauniversityorauniversityofappliedsciencesHB 
    Pleaseselectwhichofthefollowingoptionsismostapplicabletoyou Howmuchmoneydoyouhaveavailable  
    Whichofthecategoriesbelowdoyouselfidentifywith 
  /INTO Nationality Country_of_residence Student_status Study_work_status Money_available 
    Subjective_weight_status
  /PRINT.

RECODE Student_status (1=SYSMIS).
EXECUTE. 

RECODE Study_work_status (1=SYSMIS).
EXECUTE.

RECODE Money_available (1=SYSMIS).
EXECUTE.

RECODE Subjective_weight_status (1=99)(5=6)(7=1)(3=2)(4=3)(2=4)(6=5).
EXECUTE.

RECODE Subjective_weight_status (99=SYSMIS).

VALUE LABELS
Subjective_weight_status
1 'underweight'
2 'a bit underweight'
3 'appropriate weight'
4 'a bit overweight'
5 'overweight'
6 'dont want to answer'.
EXECUTE.

AUTORECODE VARIABLES=Pleaseindicatetowhatextentyouagreewiththethreestatementsbelow.  
    Pleaseindicatetowhatextentyouagreewiththethreestatementsbelow._A 
    Pleaseindicatetowhatextentyouagreewiththethreestatementsbelow._B 
  /INTO Trouble_sticking_health_goals Sticking_to_newyearsresolutions I_need_extra_commitment
  /GROUP
  /PRINT.

RECODE Trouble_sticking_health_goals (1=99)(2=1)(3=10)(4=2)(5=3)(6=4)(7=5)(8=6)(9=7)(10=8)(11=9).
EXECUTE.

RECODE Trouble_sticking_health_goals (99=SYSMIS).

VALUE LABELS
Trouble_sticking_health_goals
1 'Totally disagree'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'
8 '8'
9 '9'
10 'totally agree'.
EXECUTE.

RECODE Sticking_to_newyearsresolutions (1=99)(2=1)(3=10)(4=2)(5=3)(6=4)(7=5)(8=6)(9=7)(10=8)(11=9).
EXECUTE.

RECODE Sticking_to_newyearsresolutions (99=SYSMIS).

VALUE LABELS
Sticking_to_newyearsresolutions
1 'Totally disagree'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'
8 '8'
9 '9'
10 'totally agree'.
EXECUTE.

RECODE I_need_extra_commitment (1=99)(2=1)(3=10)(4=2)(5=3)(6=4)(7=5)(8=6)(9=7)(10=8)(11=9).
EXECUTE.

RECODE I_need_extra_commitment (99=SYSMIS).

VALUE LABELS
I_need_extra_commitment
1 'Totally disagree'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'
8 '8'
9 '9'
10 'totally agree'.
EXECUTE.

AUTORECODE VARIABLES=Pleaseindicatetowhatextentyouarewillingtotakerisksingeneral.Plea 
  /INTO Risk_proneness
  /PRINT.

RECODE Risk_proneness (1=99)(2=1)(3=10)(4=2)(5=3)(6=4)(7=5)(8=6)(9=7)(10=8)(11=9).
EXECUTE.

RECODE Risk_proneness (99=SYSMIS).

VALUE LABELS
Risk_proneness
1 'Not at all willing to take risks'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'
8 '8'
9 '9'
10 'very willing to take risks'.
EXECUTE.

AUTORECODE VARIABLES=Weareinterestedinfindingoutaboutthekindsofphysicalactivitiesthat 
  /INTO Vigorous_activities_days
  /PRINT.

RECODE Vigorous_activities_days (1=99)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6)(8=7)(9=0).
EXECUTE.

RECODE Vigorous_activities_days (99=SYSMIS).

VALUE LABELS
Vigorous_activities_days
0 '0'
1 '1'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'.
EXECUTE.

AUTORECODE VARIABLES=Thinkaboutallthemoderateactivitiesthatyoudidinthelast7days.Moder 
    Thinkaboutthetimeyouspentwalkinginthelast7days.Thisincludesatwor 
  /INTO Moderate_activities_days Walking_activities_days
  /PRINT.

RECODE Moderate_activities_days (1=99)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6)(8=7)(9=0).
EXECUTE.

RECODE Moderate_activities_days (99=SYSMIS).

VALUE LABELS
Moderate_activities_days
0 '0'
1 '1'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'.
EXECUTE.

RECODE Walking_activities_days (1=99)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6)(8=7)(9=0).
EXECUTE.

RECODE Walking_activities_days (99=SYSMIS).

VALUE LABELS
Walking_activities_days
0 '0'
1 '1'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'.
EXECUTE.

*to epxlore the role of risk taking. Automatic recode of the string variable

AUTORECODE VARIABLES=Pleaseindicatetowhatextentyouarewillingtotakerisksingeneral.Plea 
  /INTO Risktaking
  /PRINT.

RECODE Risktaking (1=1)(2=10)(3=2)(4=3)(5=4)(6=5)(7=6)(8=7)(9=8)(10=9).
EXECUTE.

RECODE Risktaking (99=SYSMIS).

VALUE LABELS
Risktaking
1 'not at all willing to take risks'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'
8 '8'
9 '9'
10 'very willing to take risks'.
EXECUTE.

*add variable that codes for whether goal was tailored or default

RECODE @$stepGoal (10000=0) (ELSE=1) INTO Goal_type.
VARIABLE LABELS  Goal_type 'Goal_type'.
EXECUTE.

VALUE LABELS
Goal_type
0 'default'
1 'tailored'.
EXECUTE.

*autorecode self monitoring frequency items
    
AUTORECODE VARIABLES=Frequency_selfmonitoring_stepcount Frequency_selfmonitoring_goalachievement 
  /INTO selfmonitoring_steps selfmonitoring_goals
  /PRINT.

*make self monitoring scale
    
COMPUTE Selfmonitoring_scale=selfmonitoring_steps+selfmonitoring_goals.
EXECUTE.

*renaming variables that code for the minutes/hours spent doing activities 

RENAME VARIABLES (Howmuchtimedidyouusuallyspenddoingvigorousphysicalactivitiesonon = Vigorous_activities_hours).
EXECUTE.

VARIABLE LABELS Vigorous_activities_hours 'Vigorous_activities_hours'.

RENAME VARIABLES (Howmuchtimedidyouusuallyspenddoingvigorousphysicalactivitieson_A = Vigorous_activities_minutes).
EXECUTE.

VARIABLE LABELS Vigorous_activities_minutes 'Vigorous_activities_minutes'.

RENAME VARIABLES (Howmuchtimedidyouusuallyspenddoing moderate physicalactivities = Moderate_activities_hours).
EXECUTE.

VARIABLE LABELS Moderate_activities_hours 'Moderate_activities_hours'.


RENAME VARIABLES (Howmuchtimedidyouusuallyspenddoing moderate physicalactiviti_A = Moderate_activities_minutes).
EXECUTE.

VARIABLE LABELS Moderate_activities_minutes 'Moderate_activities_minutes'.


RENAME VARIABLES (Howmuchtimedidyouusuallyspendwalking onone ofthosedays Asanex= Walking_activities_hours).
EXECUTE.

VARIABLE LABELS Walking_activities_hours 'Walking_activities_hours'.

RENAME VARIABLES (Howmuchtimedidyouusuallyspendwalking onone ofthosedays Asan_A = Walking_activities_minutes).
EXECUTE.

VARIABLE LABELS Walking_activities_minutes 'Walking_activities_minutes'.


RENAME VARIABLES (Thelastquestionisaboutthetimeyouspentsittingonweekdaysduringthel = Sitting_activities_hours).
EXECUTE.

VARIABLE LABELS Sitting_activities_hours 'Sitting_activities_hours'.

RENAME VARIABLES (Thelastquestionisaboutthetimeyouspentsittingonweekdaysduringth_A = Sitting_activities_minutes).
EXECUTE.

VARIABLE LABELS Sitting_activities_minutes 'Sitting_activities_minutes'.
EXECUTE.

AUTORECODE VARIABLES=Pleaseanswerthefollowingstatementsaboutyourconfidenceinbeingable 
    Pleaseanswerthefollowingstatementsaboutyourconfidenceinbeingab_A 
    Pleaseanswerthefollowingstatementsaboutyourconfidenceinbeingab_B 
    Pleaseanswerthefollowingstatementsaboutyourconfidenceinbeingab_C 
    Pleaseanswerthefollowingstatementsaboutyourconfidenceinbeingab_D 
  /INTO Selfefficacy_tired Selfefficacy_badmood Selfefficacy_donthavetime Selfefficacy_vacation 
    Selfefficacy_rainingsnowing
   /GROUP
  /PRINT.

RECODE Selfefficacy_tired (1=99)(8=98)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6).
EXECUTE.

RECODE Selfefficacy_tired (99=SYSMIS).

MISSING VALUES Selfefficacy_tired (98).

VALUE LABELS
Selfefficacy_tired
1 'Not confident at all'
2 '2'
3 '3'
4 '4'
5 '5'
6 'Very confident'.
EXECUTE.

RECODE Selfefficacy_badmood (1=99)(8=98)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6).
EXECUTE.

RECODE Selfefficacy_badmood (99=SYSMIS).

MISSING VALUES Selfefficacy_badmood (98).

VALUE LABELS
Selfefficacy_badmood
1 'Not confident at all'
2 '2'
3 '3'
4 '4'
5 '5'
6 'Very confident'.
EXECUTE.

RECODE Selfefficacy_donthavetime (1=99)(8=98)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6).
EXECUTE.

RECODE Selfefficacy_donthavetime (99=SYSMIS).

MISSING VALUES Selfefficacy_donthavetime (98).

VALUE LABELS
Selfefficacy_donthavetime
1 'Not confident at all'
2 '2'
3 '3'
4 '4'
5 '5'
6 'Very confident'.
EXECUTE.

RECODE Selfefficacy_vacation (1=99)(8=98)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6).
EXECUTE.

RECODE Selfefficacy_vacation (99=SYSMIS).

MISSING VALUES Selfefficacy_vacation (98).

VALUE LABELS
Selfefficacy_vacation
1 'Not confident at all'
2 '2'
3 '3'
4 '4'
5 '5'
6 'Very confident'.
EXECUTE.

RECODE Selfefficacy_rainingsnowing (1=99)(8=98)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6).
EXECUTE.

RECODE Selfefficacy_rainingsnowing (99=SYSMIS).

MISSING VALUES Selfefficacy_rainingsnowing (98).

VALUE LABELS
Selfefficacy_rainingsnowing
1 'Not confident at all'
2 '2'
3 '3'
4 '4'
5 '5'
6 'Very confident'.
EXECUTE.

AUTORECODE VARIABLES=Belowyouwillfind alistofstatementseachofwhichmayormaynot betru 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_A 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_B 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_C 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_D 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_E 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_F 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_G 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_H 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_I 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_J 
    Belowyouwillfind alistofstatementseachofwhichmayormaynot bet_K 
  /INTO Socialsupport_1 Socialsupport_2 Socialsupport_3 Socialsupport_4 Socialsupport_5 
    Socialsupport_6 Socialsupport_7 Socialsupport_8 Socialsupport_9 Socialsupport_10 Socialsupport_11 
    Socialsupport_12
  /PRINT.

RECODE Socialsupport_1 to Socialsupport_12 (1=99)(2=1)(3=2)(4=3)(5=4).
EXECUTE.

RECODE Socialsupport_1 to Socialsupport_12 (99=SYSMIS).

VALUE LABELS
Socialsupport_1 to Socialsupport_12
1 'definitely false'
2 'probably false'
3 'probably true'
4 'definitely true'.
EXECUTE.

AUTORECODE VARIABLES=Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttoknoww 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_A 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_B 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_C 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_D 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_E 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_F 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_G 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_H 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_I 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_J 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_K 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_L 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_M 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_N 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_O 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_P 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_Q 
    Youarealmostdone.Thisisthefinalpagewithquestions. Wewanttokno_R 
  /INTO TSRQ_AUTO1_responsibility TSRQ_INTRO1_guiltyashemed TSRQ_EXREWARD1_earnrewards TSRQ_AUTO2_bestformyhealth 
    TSRQ_EXSOCIAL1_upsetothers TSRQ_EXREWARD2_asmuchrewardsaspossible TSRQ_AUTO3_carefullythoughtimportancelife TSRQ_INTRO2_feelbad 
    TSRQ_EXREWARD3_angrynotgettingrewards TSRQ_AUTO4_importantchoice TSRQ_EXSOCIAL2_pressureothers TSRQ_EXREWARD4_pressurerewards 
    TSRQ_AUTO5_consistentlifegoals TSRQ_EXSOCIAL3_approvalothers TSRQ_EXREWARD5_proudforearningrewards 
    TSRQ_AUTO6_importanttolivehealthy TSRQ_EXSOCIAL4_showothersicandoit TSRQ_EXREWARD6_earndrewardstoshowotherssicandoit 
    TSRQ_EXMEDS_reducemeds
  /GROUP
  /PRINT.

RECODE TSRQ_AUTO1_responsibility to TSRQ_EXMEDS_reducemeds (1=99)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6)(8=7).
EXECUTE.

RECODE TSRQ_AUTO1_responsibility to TSRQ_EXMEDS_reducemeds (99=SYSMIS).

VALUE LABELS
TSRQ_AUTO1_responsibility to TSRQ_EXMEDS_reducemeds
1 'Totally disagree'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 'Totally agree'.
EXECUTE.

AUTORECODE VARIABLES=FINAL_Howfrequentlyhaveyoucheckedyourstepcountintheprevious20day 
    FINAL_Howfrequentlyhaveyoucheckedhowcloseyouweretoachievingyours 
  /INTO Frequency_selfmonitoring_stepcount Frequency_selfmonitoring_goalachievement
  /PRINT.

RECODE Frequency_selfmonitoring_stepcount to Frequency_selfmonitoring_goalachievement (1=99)(2=1)(3=2)(4=3)(5=4)(6=5).
EXECUTE.

RECODE Frequency_selfmonitoring_stepcount to Frequency_selfmonitoring_goalachievement (99=SYSMIS).

VALUE LABELS
Frequency_selfmonitoring_stepcount to Frequency_selfmonitoring_goalachievement
1 'Not at all'
2 'Several days'
3 'More than half the days'
4 'Nearly every day'
5 'Many times a day'.
EXECUTE.

AUTORECODE VARIABLES=FINAL_Pleaseindicatetowhatextentyouagreewiththethreestatementsbe 
    FINAL_Pleaseindicatetowhatextentyouagreewiththethreestatements_A 
    FINAL_Pleaseindicatetowhatextentyouagreewiththethreestatements_B 
  /INTO Felt_losingmoney Committed_increase_mystepcount Carried_smartphone_moreoften
   /GROUP
  /PRINT.

RECODE Felt_losingmoney to Carried_smartphone_moreoften (1=99)(2=1)(3=10)(4=2)(5=3)(6=4)(7=5)(8=6)(9=7)(10=8)(11=9).
EXECUTE.

RECODE Felt_losingmoney to Carried_smartphone_moreoften (99=SYSMIS).

MISSING VALUES Felt_losingmoney (12).
MISSING VALUES Committed_increase_mystepcount (12).
MISSING VALUES Carried_smartphone_moreoften (12).

VALUE LABELS
Felt_losingmoney to Carried_smartphone_moreoften
1 'Totally disagree'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'
8 '8'
9 '9'
10 'totally agree'.
EXECUTE.

AUTORECODE VARIABLES=FINAL_Didyoucheatthesysteminanywaydonotworryyouwillreceiveyourin 
  /INTO Cheat
  /PRINT.

RECODE Cheat (1=SYSMIS).
Execute.

AUTORECODE VARIABLES=FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_A 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_B 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_C 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_D 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_E 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_F 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_G 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_H 
    FINAL_Pleaseindicatetowhatextentyouagreewiththestatementsbelow_I 
  /INTO Intervention_Fair Intervention_Fun Intervention_helpful Intervention_easytouse 
    Intervention_Convenient Intervention_Acceptable Intervention_recommend 
    Intervention_likedmonitoringsteps Intervention_likedearningrewards Intervention_Rewardswerehelpful
   /GROUP
  /PRINT.

RECODE Intervention_Fair to Intervention_Rewardswerehelpful (1=99)(2=1)(3=10)(4=2)(5=3)(6=4)(7=5)(8=6)(9=7)(10=8)(11=9).
EXECUTE.

RECODE Intervention_Fair to Intervention_Rewardswerehelpful (99=SYSMIS).
EXECUTE.

MISSING VALUES Intervention_Fair (12).
MISSING VALUES Intervention_Fun (12).
MISSING VALUES Intervention_helpful (12).
MISSING VALUES Intervention_easytouse (12).
MISSING VALUES Intervention_Convenient (12).
MISSING VALUES Intervention_Acceptable (12).
MISSING VALUES Intervention_recommend (12).
MISSING VALUES Intervention_likedmonitoringsteps (12).
MISSING VALUES Intervention_likedearningrewards (12).
MISSING VALUES Intervention_Rewardswerehelpful (12).

VALUE LABELS
Intervention_Fair to Intervention_Rewardswerehelpful
1 'Totally disagree'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'
8 '8'
9 '9'
10 'totally agree'.
EXECUTE.

AUTORECODE VARIABLES=FINAL_Wouldyouliketoparticipateinthesameinterventionforanother3w 
    FINAL_Didyouhaveexamsduringtheinterventionperiodofthisstudy  
    FINAL_Didyouknowotherpeoplewhowerealsoparticipatinginthisexperim 
    FINAL_Didyoudiscusstheexperimentwiththem  FINAL_Didyouknowaboutwhattheywererequiredtodoforthestudy  
    FINAL_Didyouexperienceflulikesymptomslikefevercoughingandortroub 
    FINAL_Didyouengageinlessphysicalactivityduetothesesymptoms 
    FINAL_Didyouengageinlessphysicalactivitythanusualduetothecurrent 
  /INTO Participate_again Exams Aware_others Discuss_others Knew_conditiondetails_others 
    Flu_symptoms Less_activity_duetoflu Less_activity_duetoCorona
  /PRINT.

RECODE Participate_again to Less_activity_duetoCorona (1=SYSMIS).
Execute.

AUTORECODE VARIABLES=FINAL_Overthelastthreeweekshowoftenhaveyoubeenbotheredbythefollo 
    FINAL_Overthelastthreeweekshowoftenhaveyoubeenbotheredbythefol_A 
    FINAL_Overthelastthreeweekshowoftenhaveyoubeenbotheredbythefol_B 
    FINAL_Overthelastthreeweekshowoftenhaveyoubeenbotheredbythefol_C 
    FINAL_Overthelastthreeweekshowoftenhaveyoubeenbotheredbythefol_D 
    FINAL_Overthelastthreeweekshowoftenhaveyoubeenbotheredbythefol_E 
    FINAL_Overthelastthreeweekshowoftenhaveyoubeenbotheredbythefol_F 
  /INTO Anxiety_nervous Anxiety_stop_worrying Anxiety_worrying_differentthings 
    Anxiety_trouble_relaxing Anxiety_restless Anxiety_irritable Anxiety_afraid
  /PRINT.

RECODE Anxiety_nervous to Anxiety_afraid (1=99)(2=1)(3=2)(4=3)(5=4).
EXECUTE.

RECODE Anxiety_nervous to Anxiety_afraid (99=SYSMIS).

VALUE LABELS
Anxiety_nervous to Anxiety_afraid 
1 'Not at all'
2 'Several days'
3 'More than half the days'
4 'Nearly every day'. 
EXECUTE.

AUTORECODE VARIABLES=FINAL_Ifyoucheckedoffanyproblemshowdifficulthavetheseproblemsmad 
  /INTO Anxiety_howdifficult
  /PRINT.

RECODE Anxiety_howdifficult (1=99)(2=1)(3=2)(4=3)(5=4). 
EXECUTE.

RECODE Anxiety_howdifficult (99=SYSMIS).

MISSING VALUES Anxiety_howdifficult (6).

VALUE LABELS
Anxiety_howdifficult
1 'not difficult at all'
2 'somewhat difficult'
3 'very difficult'
4 'extremely difficult'.
EXECUTE.

AUTORECODE VARIABLES=FINAL_Weareinterestedinfindingoutaboutthekindsofphysicalactiviti 
    FINAL_Thinkaboutallthemoderateactivitiesthatyoudidinthelast7days 
    FINAL_Thinkaboutthetimeyouspentwalkinginthelast7days.Thisinclude 
  /INTO FINAL_Vigorous_activities_days FINAL_Moderate_activities_days FINAL_Walking_activities_days
  /PRINT.

RECODE FINAL_Vigorous_activities_days to FINAL_Walking_activities_days (1=99)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6)(8=7)(9=0).
EXECUTE.

RECODE FINAL_Vigorous_activities_days to FINAL_Walking_activities_days (99=SYSMIS).

VALUE LABELS
FINAL_Vigorous_activities_days to FINAL_Walking_activities_days
0 '0'
1 '1'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 '7'.
EXECUTE.

AUTORECODE VARIABLES=FINAL_Pleaseanswerthefollowingstatementsaboutyourconfidenceinbei 
    FINAL_Pleaseanswerthefollowingstatementsaboutyourconfidenceinb_A 
    FINAL_Pleaseanswerthefollowingstatementsaboutyourconfidenceinb_B 
    FINAL_Pleaseanswerthefollowingstatementsaboutyourconfidenceinb_C 
    FINAL_Pleaseanswerthefollowingstatementsaboutyourconfidenceinb_D 
  /INTO FINAL_Selfefficacy_tired FINAL_Selfefficacy_badmood FINAL_Selfefficacy_donthavetime 
    FINAL_Selfefficacy_vacation FINAL_Selfefficacy_rainingsnowing
    /GROUP
  /PRINT.

RECODE FINAL_Selfefficacy_tired to FINAL_Selfefficacy_rainingsnowing (1=99)(8=98)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6).
EXECUTE.

RECODE FINAL_Selfefficacy_tired to FINAL_Selfefficacy_rainingsnowing (99=SYSMIS).

MISSING VALUES FINAL_Selfefficacy_tired (98).
MISSING VALUES FINAL_Selfefficacy_badmood (98).
MISSING VALUES FINAL_Selfefficacy_donthavetime (98).
MISSING VALUES FINAL_Selfefficacy_vacation (98).
MISSING VALUES FINAL_Selfefficacy_rainingsnowing (98).

VALUE LABELS
FINAL_Selfefficacy_tired to FINAL_Selfefficacy_rainingsnowing
1 'Not confident at all'
2 '2'
3 '3'
4 '4'
5 '5'
6 'Very confident'.
EXECUTE.

AUTORECODE VARIABLES=FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewantt 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_A 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_B 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_C 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_D 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_E 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_F 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_G 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_H 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_I 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_J 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_K 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_L 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_M 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_N 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_O 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_P 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_Q 
    FINAL_Youarealmostdone.Thisisthefinalpagewithquestions. Wewan_R 
  /INTO FINAL_TSRQ_AUTO1_responsibility FINAL_TSRQ_INTRO1_guiltyashemed FINAL_TSRQ_EXREWARD1_earnrewards FINAL_TSRQ_AUTO2_bestformyhealth 
    FINAL_TSRQ_EXSOCIAL1_upsetothers FINAL_TSRQ_EXREWARD2_asmuchrewardsaspossible FINAL_TSRQ_AUTO3_carefullythoughtimportancelife FINAL_TSRQ_INTRO2_feelbad 
    FINAL_TSRQ_EXREWARD3_angrynotgettingrewards FINAL_TSRQ_AUTO4_importantchoice FINAL_TSRQ_EXSOCIAL2_pressureothers FINAL_TSRQ_EXREWARD4_pressurerewards 
    FINAL_TSRQ_AUTO5_consistentlifegoals FINAL_TSRQ_EXSOCIAL3_approvalothers FINAL_TSRQ_EXREWARD5_proudforearningrewards 
    FINAL_TSRQ_AUTO6_importanttolivehealthy FINAL_TSRQ_EXSOCIAL4_showothersicandoit FINAL_TSRQ_EXREWARD6_earndrewardstoshowotherssicandoit 
    FINAL_TSRQ_EXMEDS_reducemeds
   /GROUP
  /PRINT.

RECODE FINAL_TSRQ_AUTO1_responsibility to FINAL_TSRQ_EXMEDS_reducemeds (1=99)(2=1)(3=2)(4=3)(5=4)(6=5)(7=6)(8=7).
EXECUTE.

RECODE FINAL_TSRQ_AUTO1_responsibility to FINAL_TSRQ_EXMEDS_reducemeds (99=SYSMIS).

VALUE LABELS
FINAL_TSRQ_AUTO1_responsibility to FINAL_TSRQ_EXMEDS_reducemeds
1 'Totally disagree'
2 '2'
3 '3'
4 '4'
5 '5'
6 '6'
7 'Totally agree'.
EXECUTE.

*manual recoding + value labels 

DATASET ACTIVATE DataSet1.

RECODE Study_work_status (1=98).
EXECUTE.

VALUE LABELS
Study_work_status
98 'I dont want to answer this question'
2 'student with a job'
3 'student without a job'
4 'working full time'
5 'working part time'.
EXECUTE.

*create a variable that codes for whether PPN belonged to control or 1 of 4 intervention groups

RECODE @$groupNo (1=0) (2=1) (3=1) (4=1) (5=1) INTO Intervention_vs_control.
VARIABLE LABELS Intervention_vs_control 'Intervention_vs_control'.
EXECUTE.

VALUE LABELS
Intervention_vs_control
0 'control'
1 'Intervention'.
EXECUTE.

*create a variable that codes for whether PPN belonged to control or reward group

RECODE @$groupNo (1=0) (2=1) (3=SYSMIS) (4=1) (5=SYSMIS) INTO Control_vs_Reward.
VARIABLE LABELS Control_vs_Reward 'Control_vs_Reward'.
EXECUTE.

VALUE LABELS
Control_vs_Reward
0 'control'
1 'Reward'.
EXECUTE.

*create a variable that codes for whether PPN belonged to control or deposit group

RECODE @$groupNo (1=0) (2=SYSMIS) (3=1) (4=SYSMIS) (5=1) INTO Control_vs_Deposit.
VARIABLE LABELS Control_vs_Deposit 'Control_vs_Deposit'.
EXECUTE.

VALUE LABELS
Control_vs_Deposit
0 'control'
1 'Deposit'.
EXECUTE.

*create a variable that codes for whether PPN belonged to control or gain framed group

RECODE @$groupNo (1=0) (2=1) (3=1) (4=SYSMIS) (5=SYSMIS) INTO Control_vs_Gain.
VARIABLE LABELS Control_vs_Gain 'Control_vs_Gain'.
EXECUTE.

VALUE LABELS
Control_vs_Gain
0 'control'
1 'Gain'.
EXECUTE.

*create a variable that codes for whether PPN belonged to control or loss framed group

RECODE @$groupNo (1=0) (2=SYSMIS) (3=SYSMIS) (4=1) (5=1) INTO Control_vs_Loss.
VARIABLE LABELS Control_vs_Loss 'Control_vs_Loss'.
EXECUTE.

VALUE LABELS
Control_vs_Loss
0 'control'
1 'Loss'.
EXECUTE.


*Create variable uptake that codes for whether people finished baseline, then explicitly opted out (uptake check yes)  or did not perform deposit (payment pending)

DATASET ACTIVATE DataSet1.
AUTORECODE VARIABLES=@$uptakeCheck 
  /INTO Uptakecheck
  /PRINT.

IF  (Uptakecheck=2) Uptake=0.
EXECUTE.

AUTORECODE VARIABLES=@$studyPhase 
  /INTO Studyphase
  /PRINT.

IF  (Studyphase=4) Uptake=0.
EXECUTE.

RECODE Uptake (SYSMIS=1).
EXECUTE.

*compute variable for IPAQ total minutes doing activities per week BASELINE

DATASET ACTIVATE DataSet1.
COMPUTE Vigorous_activities_total_minutes_week=Vigorous_activities_days  * 
    (Vigorous_activities_minutes + (Vigorous_activities_hours*60)).
EXECUTE.

COMPUTE Moderate_activities_total_minutes_week=Moderate_activities_days  * 
    (Moderate_activities_minutes + (Moderate_activities_hours*60)).
EXECUTE.

COMPUTE Walking_activities_total_minutes_week=Walking_activities_days  * 
    (Walking_activities_minutes + (Walking_activities_hours*60)).
EXECUTE.

COMPUTE Sitting_activities_total_minutes_week=7 * (Sitting_activities_minutes + 
    (Sitting_activities_hours*60)).
EXECUTE.

*compute variable for IPAQ total minutes doing activities per week FINAL SURVEY


*compute subscales for TSRQ

*baseline TSRQ

COMPUTE TSRQ_AUTO_subscale=(TSRQ_AUTO1_responsibility + TSRQ_AUTO2_bestformyhealth + 
    TSRQ_AUTO3_carefullythoughtimportancelife + TSRQ_AUTO4_importantchoice + 
    TSRQ_AUTO5_consistentlifegoals + TSRQ_AUTO6_importanttolivehealthy)/6.
EXECUTE.

COMPUTE TSRQ_INTROJECTED_subscale=(TSRQ_INTRO1_guiltyashemed+TSRQ_INTRO2_feelbad)/2.
EXECUTE.

COMPUTE TSRQ_EXTERNALREWARD_subscale=(TSRQ_EXREWARD1_earnrewards+
    TSRQ_EXREWARD2_asmuchrewardsaspossible+TSRQ_EXREWARD3_angrynotgettingrewards+
    TSRQ_EXREWARD4_pressurerewards+TSRQ_EXREWARD5_proudforearningrewards+
    TSRQ_EXREWARD6_earndrewardstoshowotherssicandoit)/6.
EXECUTE.

COMPUTE TSRQ_EXTERNALSOCIAL_subscale=(TSRQ_EXSOCIAL1_upsetothers+TSRQ_EXSOCIAL2_pressureothers+
    TSRQ_EXSOCIAL3_approvalothers+TSRQ_EXSOCIAL4_showothersicandoit)/4.
EXECUTE.

COMPUTE TSRQ_EXTRINSIC_TOTAL_subscale=(TSRQ_INTROJECTED_subscale+TSRQ_EXTERNALREWARD_subscale+
    TSRQ_EXTERNALSOCIAL_subscale+TSRQ_EXMEDS_reducemeds)/4.
EXECUTE.

*FINAL TSRQ

COMPUTE FINAL_TSRQ_AUTO_subscale=(FINAL_TSRQ_AUTO1_responsibility + FINAL_TSRQ_AUTO2_bestformyhealth + 
    FINAL_TSRQ_AUTO3_carefullythoughtimportancelife + FINAL_TSRQ_AUTO4_importantchoice + 
    FINAL_TSRQ_AUTO5_consistentlifegoals + FINAL_TSRQ_AUTO6_importanttolivehealthy)/6.
EXECUTE.

COMPUTE FINAL_TSRQ_INTROJECTED_subscale=(FINAL_TSRQ_INTRO1_guiltyashemed+FINAL_TSRQ_INTRO2_feelbad)/2.
EXECUTE.

COMPUTE FINAL_TSRQ_EXTERNALREWARD_subscale=(FINAL_TSRQ_EXREWARD1_earnrewards+
    FINAL_TSRQ_EXREWARD2_asmuchrewardsaspossible+FINAL_TSRQ_EXREWARD3_angrynotgettingrewards+
    FINAL_TSRQ_EXREWARD4_pressurerewards+FINAL_TSRQ_EXREWARD5_proudforearningrewards+
    FINAL_TSRQ_EXREWARD6_earndrewardstoshowotherssicandoit)/6.
EXECUTE.

COMPUTE FINAL_TSRQ_EXTERNALSOCIAL_subscale=(FINAL_TSRQ_EXSOCIAL1_upsetothers+FINAL_TSRQ_EXSOCIAL2_pressureothers+
    FINAL_TSRQ_EXSOCIAL3_approvalothers+FINAL_TSRQ_EXSOCIAL4_showothersicandoit)/4.
EXECUTE.

COMPUTE FINAL_TSRQ_EXTRINSIC_TOTAL_subscale=(FINAL_TSRQ_INTROJECTED_subscale+FINAL_TSRQ_EXTERNALREWARD_subscale+
    FINAL_TSRQ_EXTERNALSOCIAL_subscale+FINAL_TSRQ_EXMEDS_reducemeds)/4.
EXECUTE.

*difference scores TSRQ

COMPUTE DIFFERENCE_TSRQ_AUTO_subscale=FINAL_TSRQ_AUTO_subscale-TSRQ_AUTO_subscale.
EXECUTE.

COMPUTE DIFFERENCE_TSRQ_INTROJECTED_subscale=
    FINAL_TSRQ_INTROJECTED_subscale-TSRQ_INTROJECTED_subscale.
EXECUTE.

COMPUTE DIFFERENCE_TSRQ_EXTERNALREWARD_subscale=
    FINAL_TSRQ_EXTERNALREWARD_subscale-TSRQ_EXTERNALREWARD_subscale.
EXECUTE.

COMPUTE DIFFERENCE_TSRQ_EXTERNALSOCIAL_subscale=
    FINAL_TSRQ_EXTERNALSOCIAL_subscale-TSRQ_EXTERNALSOCIAL_subscale.
EXECUTE.

COMPUTE DIFFERENCE_TSRQ_EXTRINSIC_TOTAL_subscale=
    FINAL_TSRQ_EXTRINSIC_TOTAL_subscale-TSRQ_EXTRINSIC_TOTAL_subscale.
EXECUTE.

*scale for social support


*solve issue with birthyear to age (measurement done in march 2020, so assuming random distribution of birth dates)

DATASET ACTIVATE DataSet1.
COMPUTE AgeRough=2020 - Whatisyourbirthyear .
EXECUTE.

COMPUTE AgeCorrected=(((AgeRough-1)*9)+((AgeRough+1)*3))/12.
EXECUTE.

*recode uptake variables 

DATASET ACTIVATE DataSet1.
AUTORECODE VARIABLES=@$uptake @$uptakeCheck 
  /INTO UptakeNew UptakeCheckNew
  /PRINT.

RECODE ID (38=0) (42=0) (66=0) (104=0) (32=0) (43=0) (109=0) (111=0) (114=0) (122=0) (124=0) (22=0) 
    (33=0) (65=0) (90=0) (1=0) (17=0) (118=0) (ELSE=1) INTO Uptake_def.
EXECUTE.

RECODE ID (38=0) (42=0) (66=0) (104=0) (32=0) (43=0) (109=0) (111=0) (114=0) (122=0) (124=0) (22=0) 
    (33=0) (65=0) (90=0) (1=0) (17=0) (118=0) (12=0) (108=0) (70=0) (116=0) (121=0) (83=0) (44=0) (40=0) (24=0) (30=0) (10=0) (11=0) (ELSE=1) INTO Uptake_def_strict.
EXECUTE.



*create scale for self-efficacy baseline

COMPUTE Baseline_Total_SE=(Selfefficacy_tired+Selfefficacy_badmood+Selfefficacy_donthavetime+
    Selfefficacy_vacation+Selfefficacy_rainingsnowing)/5.
EXECUTE.

*create scale for self-efficacy final measurement

COMPUTE Final_Total_SE=(FINAL_Selfefficacy_tired+FINAL_Selfefficacy_badmood+
    FINAL_Selfefficacy_donthavetime+FINAL_Selfefficacy_vacation+FINAL_Selfefficacy_rainingsnowing)/5.
EXECUTE.

*create difference score for self-efficacy

COMPUTE DIFF_Total_SE=Final_Total_SE-Baseline_Total_SE.
EXECUTE.

*create scale for self-control items

*recode item 2

RECODE Sticking_to_newyearsresolutions (1=10) (2=9) (3=8) (4=7) (5=6) (6=5) (7=4) (8=3) (9=2) 
    (10=1) INTO Sticking_to_newyearsresolutions_recoded.
EXECUTE.

*create the scale itself for use in analysis

COMPUTE Selfcontrol_scale=(Sticking_to_newyearsresolutions_recoded+Trouble_sticking_health_goals+
    I_need_extra_commitment)/3.
EXECUTE.


*create scale for intervention assesment

COMPUTE InterventionAsses_scale=(Intervention_Fair+Intervention_Fun+Intervention_helpful+
    Intervention_easytouse+Intervention_Convenient+Intervention_Acceptable+Intervention_recommend+
    Intervention_likedmonitoringsteps+Intervention_likedearningrewards+Intervention_Rewardswerehelpful)
    /10.
EXECUTE.


*create dummy variables 
    
DATASET ACTIVATE DataSet1.
SPSSINC CREATE DUMMIES VARIABLE=Money_available 
ROOTNAME1=Income 
/OPTIONS ORDER=A USEVALUELABELS=YES USEML=YES OMITFIRST=NO.

SPSSINC CREATE DUMMIES VARIABLE=Subjective_weight_status 
ROOTNAME1=Weight 
/OPTIONS ORDER=A USEVALUELABELS=YES USEML=YES OMITFIRST=NO.


*create scale for GAD-7
    
COMPUTE GAD7_Total=(Anxiety_nervous+Anxiety_stop_worrying+Anxiety_worrying_differentthings+
    Anxiety_trouble_relaxing+Anxiety_restless+Anxiety_irritable+Anxiety_afraid) / 7.
EXECUTE.

*create step increase variable
    
DATASET ACTIVATE DataSet1.
COMPUTE Steps_increase=@$averageSteps-@$historicAvgSteps.
EXECUTE.

*create goal type variable
    
RECODE @$stepGoal (10000=0) (ELSE=1) INTO Goal_type.
EXECUTE.



************************************************************formal analysis performed on 29-07-2021***********************************************************


*select all who finished the baseline survey + exclude 2 persons over 30 years of age

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*run explortations for demographics table

DATASET ACTIVATE DataSet1.
FREQUENCIES VARIABLES=Gender Nationality Country_of_residence Student_status Study_work_status 
    Money_available Subjective_weight_status AgeCorrected
  /STATISTICS=STDDEV MEAN
  /BARCHART FREQ
  /ORDER=ANALYSIS.

DATASET ACTIVATE DataSet1.
FREQUENCIES
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

SORT CASES  BY Groups.
SPLIT FILE LAYERED BY Groups.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps)

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*Determine descriptives total and per condition 

*split file by groups

SORT CASES  BY Groups.
SPLIT FILE LAYERED BY Groups.

*rerun explortations for demographics tables

DATASET ACTIVATE DataSet1.
FREQUENCIES VARIABLES=Gender Nationality Country_of_residence Student_status Study_work_status 
    Money_available Subjective_weight_status AgeCorrected
  /STATISTICS=STDDEV MEAN
  /BARCHART FREQ
  /ORDER=ANALYSIS.

DATASET ACTIVATE DataSet1.
FREQUENCIES VARIABLES=Gender Nationality Country_of_residence Student_status Study_work_status 
    Money_available Subjective_weight_status AgeCorrected
  /BARCHART FREQ
  /ORDER=ANALYSIS.

*run explorations

USE ALL.
COMPUTE filter_$=(UptakeNew=2&UptakeCheckNew=3).
VARIABLE LABELS filter_$ 'UptakeNew=2&UptakeCheckNew=3 (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.

DESCRIPTIVES VARIABLES=@$averageSteps @$historicAvgSteps @$stepGoal @$daysAchievedGoal
  /STATISTICS=MEAN STDDEV MIN MAX.

SORT CASES  BY Groups.
SPLIT FILE LAYERED BY Groups.

DESCRIPTIVES VARIABLES=@$averageSteps @$historicAvgSteps @$stepGoal @$daysAchievedGoal
  /STATISTICS=MEAN STDDEV MIN MAX.

FREQUENCIES VARIABLES=@$stepGoal
  /ORDER=ANALYSIS.

*formal analysis Chi square for uptake 

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT groups = 1).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

CROSSTABS
  /TABLES=Uptake_def BY Incentive_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

*second chi square with more strict defnition op uptake (also excluding those with technical errors or never retrived any steps)

CROSSTABS
  /TABLES=Uptake_def_strict BY Incentive_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

*formal analysis ANOVA comparing all groups

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps)

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

UNIANOVA @$daysAchievedGoal BY Groups
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Groups) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Groups.

*repeated with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Groups WITH @$historicAvgSteps
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Groups.

*formal analysis two-way ANOVA 

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type.

*repeated with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.

*exploraty analysis 1: only ppn with tailored goals

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

UNIANOVA @$daysAchievedGoal BY Groups
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Groups) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Groups.

*repeated with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Groups WITH @$historicAvgSteps
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Groups.

*formal analysis two-way ANOVA 

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type.

*repeated with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.

*exploratory analysis






*exploration of effects on motivation

*recode necesaary for analysis of deposit VS control

RECODE Groups (1=1) (2=99) (4=99) (3=2) (5=2) INTO DepositVScontrol.
EXECUTE.

VALUE LABELS
DepositVScontrol
99 'reward'
1 'control'
2 'Deposit'.
EXECUTE.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in reward groups

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=2) and (NOT groups=4). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*run analysis

UNIANOVA DIFFERENCE_TSRQ_AUTO_subscale BY DepositVScontrol
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=DepositVScontrol.

UNIANOVA DIFFERENCE_TSRQ_EXTRINSIC_TOTAL_subscale BY DepositVScontrol
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=DepositVScontrol.


*recode necesaary for analysis of rewards VS control

RECODE Groups (1=1) (2=2) (4=2) (3=99) (5=99) INTO RewardVScontrol.
EXECUTE.

VALUE LABELS
RewardVScontrol
99 'Deposit'
1 'control'
2 'Reward'.
EXECUTE.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in deposit groups

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=3) and (NOT groups=5). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*run analysis

UNIANOVA DIFFERENCE_TSRQ_AUTO_subscale BY RewardVScontrol
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=RewardVScontrol.

UNIANOVA DIFFERENCE_TSRQ_EXTRINSIC_TOTAL_subscale BY RewardVScontrol
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=RewardVScontrol.

*Repeat procedure for feedback framing

*recode necesaary for analysis of gain frame VS control

RECODE Groups (1=1) (2=2) (4=99) (3=2) (5=99) INTO GainVSControl.
EXECUTE.

VALUE LABELS
GainVSControl
99 'loss'
1 'control'
2 'gain'.
EXECUTE.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in reward groups

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=4) and (NOT groups=5). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*run analysis

UNIANOVA DIFFERENCE_TSRQ_AUTO_subscale BY GainVSControl
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=GainVSControl.

UNIANOVA DIFFERENCE_TSRQ_EXTRINSIC_TOTAL_subscale BY GainVSControl
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=GainVSControl.

*recode necesaary for analysis of loss frame VS control

RECODE Groups (1=1) (2=99) (4=2) (3=99) (5=2) INTO LossVSControl.
EXECUTE.

VALUE LABELS
LossVSControl
99 'gain'
1 'control'
2 'loss'.
EXECUTE.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in reward groups

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=2) and (NOT groups=3). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*run analysis

UNIANOVA DIFFERENCE_TSRQ_AUTO_subscale BY LossVSControl
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=LossVSControl.

UNIANOVA DIFFERENCE_TSRQ_EXTRINSIC_TOTAL_subscale BY LossVSControl
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=LossVSControl.

*general repeat of the two-way anova byt replacing effectiveness for motivation

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

UNIANOVA DIFFERENCE_TSRQ_AUTO_subscale BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /CRITERIA=ALPHA(0.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type.

UNIANOVA DIFFERENCE_TSRQ_EXTRINSIC_TOTAL_subscale BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /CRITERIA=ALPHA(0.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type.








*explore effects on goal commitment en feelings of loss

FILTER OFF.
USE ALL.
EXECUTE.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps)

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*analyses

UNIANOVA Committed_increase_mystepcount BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type.

UNIANOVA Felt_losingmoney BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type.

*reliability for SE scale

DATASET ACTIVATE DataSet1.

RELIABILITY
  /VARIABLES=Selfefficacy_tired Selfefficacy_badmood Selfefficacy_donthavetime 
    Selfefficacy_vacation Selfefficacy_rainingsnowing
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.

*moderation analysis with baseline SE

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH Baseline_Total_SE
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Baseline_Total_SE*Incentive_type Baseline_Total_SE*Feedback_frame.

*reliability for SS scale



*modertion analyssi risk taking

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH Risktaking
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type Feedback_frame*Risktaking 
    Incentive_type*Risktaking.

*reliability self control scale

RELIABILITY
  /VARIABLES=Trouble_sticking_health_goals I_need_extra_commitment 
    Sticking_to_newyearsresolutions_recoded
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.

*Exploring the predictors of uptake (over alle condities zonder split file)

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT groups = 1).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

CROSSTABS
  /TABLES=Uptake_def BY Gender
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Whichofthecategoriesbelowdoyouselfidentifywith
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Howmuchmoneydoyouhaveavailable 
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Goal_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER AgeCorrected 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).


LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Baseline_Total_SE 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Risktaking 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).


LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Selfcontrol_scale 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER TSRQ_AUTO_subscale 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER TSRQ_EXTRINSIC_TOTAL_subscale 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER @$historicAvgSteps 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

*Exploring the predictors of uptake (met split file)

SORT CASES  BY Incentive_type.
SPLIT FILE LAYERED BY Incentive_type.

CROSSTABS
  /TABLES=Uptake_def BY Gender
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Whichofthecategoriesbelowdoyouselfidentifywith
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Howmuchmoneydoyouhaveavailable 
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER AgeCorrected 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Baseline_Total_SE 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Risktaking 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Selfcontrol_scale 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).


*explore mediation by feelings of loss and goal commitment for only those with tailored goals


*exploraty analysis 1: only ppn with tailored goals

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*moderation by SE, Selfcontrol, risk taking, motivation

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH Baseline_Total_SE
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Baseline_Total_SE*Incentive_type Baseline_Total_SE*Feedback_frame.


UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH TSRQ_AUTO_subscale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE 
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Incentive_type*TSRQ_AUTO_subscale Feedback_frame*TSRQ_AUTO_subscale.


UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH TSRQ_EXTRINSIC_TOTAL_subscale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Incentive_type*TSRQ_EXTRINSIC_TOTAL_subscale Feedback_frame*TSRQ_EXTRINSIC_TOTAL_subscale.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH Selfcontrol_scale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Incentive_type*Selfcontrol_scale Feedback_frame*Selfcontrol_scale.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH Risk_proneness
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type Incentive_type*Risk_proneness 
    Feedback_frame*Risk_proneness.


*fruther explorting interaction by self-efficacy

*simple slopes plot for the interaction

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in control group

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=1). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


DATASET ACTIVATE DataSet1.
DESCRIPTIVES VARIABLES=Baseline_Total_SE
  /STATISTICS=MEAN STDDEV MIN MAX.


*median split self-efficacy to investigate interaction with incentive type

RECODE Baseline_Total_SE (Lowest thru 3.69=0) (3.7 thru Highest=1) INTO Baseline_Total_SE_median.
EXECUTE.

VALUE LABELS
Baseline_Total_SE_median
0 'low'
1 'high'.
EXECUTE.

UNIANOVA @$daysAchievedGoal BY Incentive_type Baseline_Total_SE_median
  /CONTRAST(Incentive_type)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PLOT=PROFILE(Incentive_type Incentive_type*Baseline_Total_SE_median Baseline_Total_SE_median) 
    TYPE=LINE ERRORBAR=NO MEANREFERENCE=NO YAXIS=AUTO
  /EMMEANS=TABLES(Baseline_Total_SE_median*Incentive_type) 
  /EMMEANS=TABLES(Baseline_Total_SE_median*Incentive_type) 
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Baseline_Total_SE_median Baseline_Total_SE_median*Incentive_type.










*************************assumption checks main analysis****************************************

*hypothesis 1 Participants in deposit contract conditions will have lower uptake than participants in regular reward conditions

*chi square does not reguire

*hypothesis 2 All four groups that receive a financial incentive will have higher effectiveness than the no-incentive control group

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps)

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

DATASET ACTIVATE DataSet1.
UNIANOVA @$daysAchievedGoal BY Groups
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PLOT=PROFILE(Groups) TYPE=LINE ERRORBAR=NO MEANREFERENCE=NO YAXIS=AUTO
  /EMMEANS=TABLES(Groups) 
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Groups.


EXAMINE VARIABLES=ZRE_1 BY Groups
  /PLOT BOXPLOT HISTOGRAM NPPLOT
  /COMPARE GROUPS
  /PERCENTILES(5,10,25,50,75,90,95) HAVERAGE
  /STATISTICS DESCRIPTIVES EXTREME
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.


EXAMINE VARIABLES=ZRE_1
  /PLOT BOXPLOT HISTOGRAM NPPLOT
  /COMPARE GROUPS
  /PERCENTILES(5,10,25,50,75,90,95) HAVERAGE
  /STATISTICS DESCRIPTIVES EXTREME
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.


* H3-4-5: two-way anova
    
UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PLOT=PROFILE(Incentive_type*Feedback_frame) TYPE=LINE ERRORBAR=NO MEANREFERENCE=NO YAXIS=AUTO
  /EMMEANS=TABLES(Feedback_frame*Incentive_type) 
  /EMMEANS=TABLES(Feedback_frame) 
  /EMMEANS=TABLES(Incentive_type) 
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type.

EXAMINE VARIABLES=ZRE_2 BY Groups
  /PLOT BOXPLOT HISTOGRAM NPPLOT
  /COMPARE GROUPS
  /PERCENTILES(5,10,25,50,75,90,95) HAVERAGE
  /STATISTICS DESCRIPTIVES EXTREME
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

EXAMINE VARIABLES=ZRE_2
  /PLOT BOXPLOT HISTOGRAM NPPLOT
  /COMPARE GROUPS
  /PERCENTILES(5,10,25,50,75,90,95) HAVERAGE
  /STATISTICS DESCRIPTIVES EXTREME
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.








********************formal analysis 210906****************************
    
*Hypothesis 1: deposit contract conditions will have lower uptake 

*Chi square for uptake 

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT groups = 1) AND (NOT @$stepGoal=10000).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

CROSSTABS
  /TABLES=Uptake_def BY Incentive_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

*second chi square with more strict defnition op uptake (also excluding those with technical errors or never retrived any steps)

CROSSTABS
  /TABLES=Uptake_def_strict BY Incentive_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

*Hypothesis 2: All four groups that receive a financial incentive will have higher effectiveness than the no-incentive control group

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*ANOVA with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Groups WITH @$historicAvgSteps
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Groups.

*assumption of normality
    
*overall
    
EXAMINE VARIABLES=ZRE_6
  /PLOT BOXPLOT HISTOGRAM NPPLOT
  /COMPARE GROUPS
  /PERCENTILES(5,10,25,50,75,90,95) HAVERAGE
  /STATISTICS DESCRIPTIVES EXTREME
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

*per arm

EXAMINE VARIABLES=ZRE_6 BY Groups
  /PLOT BOXPLOT HISTOGRAM NPPLOT
  /COMPARE GROUPS
  /PERCENTILES(5,10,25,50,75,90,95) HAVERAGE
  /STATISTICS DESCRIPTIVES EXTREME
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

*covariate baseline steps assumption check
   
*homogeneity of regression slopes 

UNIANOVA @$daysAchievedGoal BY Groups WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Groups @$historicAvgSteps @$historicAvgSteps*Groups.

*independence of covariate and treatment effect
    
UNIANOVA @$historicAvgSteps BY Groups
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Groups.

*scatterplot to asses linearity between covariate and DV for all groups
   

* Chart Builder.
GGRAPH
  /GRAPHDATASET NAME="graphdataset" VARIABLES=@$historicAvgSteps[name="__historicAvgSteps"] 
    @$daysAchievedGoal[name="__daysAchievedGoal"] Group MISSING=LISTWISE REPORTMISSING=NO
  /GRAPHSPEC SOURCE=INLINE
  /FITLINE TOTAL=NO SUBGROUP=NO.
BEGIN GPL
  SOURCE: s=userSource(id("graphdataset"))
  DATA: historicAvgSteps=col(source(s), name("__historicAvgSteps"))
  DATA: daysAchievedGoal=col(source(s), name("__daysAchievedGoal"), unit.category())
  DATA: Group=col(source(s), name("Group"), unit.category())
  GUIDE: axis(dim(1), label("$historicAvgSteps"))
  GUIDE: axis(dim(2), label("$daysAchievedGoal"))
  GUIDE: legend(aesthetic(aesthetic.color.interior), label("Group"))
  GUIDE: text.title(label("Scatter Plot of $daysAchievedGoal by $historicAvgSteps by Group"))
  ELEMENT: point(position(historicAvgSteps*daysAchievedGoal), color.interior(Group))
END GPL.
    

*repeat the analyses but now Kruskall Wallis
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.
    
Variable level @$daysAchievedGoal (SCALE).

*Nonparametric Tests: Independent Samples. 
NPTESTS 
  /INDEPENDENT TEST (@$daysAchievedGoal) GROUP (Groups) KRUSKAL_WALLIS(COMPARE=PAIRWISE) 
  /MISSING SCOPE=ANALYSIS USERMISSING=EXCLUDE
  /CRITERIA ALPHA=0.05  CILEVEL=95.

   
* Hypothesis 3-4-5: A deposit contract will lead to higher effectiveness & Loss framed feedback will lead to higher effectiveness & interaction
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*2-way ANOVA with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) 

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*2-way ANOVA with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.

*descriptives per group
    
DATASET ACTIVATE DataSet1.
SORT CASES  BY Groups.
SPLIT FILE LAYERED BY Groups.


DESCRIPTIVES VARIABLES=@$historicAvgSteps @$stepGoal @$daysAchievedGoal @$averageSteps
  /STATISTICS=MEAN STDDEV.

*assumption of normality
    
*overall
    
EXAMINE VARIABLES=ZRE_7
  /PLOT BOXPLOT HISTOGRAM NPPLOT
  /COMPARE GROUPS
  /PERCENTILES(5,10,25,50,75,90,95) HAVERAGE
  /STATISTICS DESCRIPTIVES EXTREME
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

*per arm

EXAMINE VARIABLES=ZRE_7 BY Groups
  /PLOT BOXPLOT HISTOGRAM NPPLOT
  /COMPARE GROUPS
  /PERCENTILES(5,10,25,50,75,90,95) HAVERAGE
  /STATISTICS DESCRIPTIVES EXTREME
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

*assumptions for the covariate

*homogeneity of regression slopes 

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    @$historicAvgSteps*Incentive_type @$historicAvgSteps*Feedback_frame.

*independence of covariate and treatment effect
    
UNIANOVA @$historicAvgSteps BY Groups
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Groups.


*scatterplot to asses linearity between covariate and DV for all groups
    
* Chart Builder.
GGRAPH
  /GRAPHDATASET NAME="graphdataset" VARIABLES=@$historicAvgSteps[name="__historicAvgSteps"] 
    @$daysAchievedGoal[name="__daysAchievedGoal"] Incentive_type MISSING=LISTWISE REPORTMISSING=NO
  /GRAPHSPEC SOURCE=INLINE
  /FITLINE TOTAL=NO SUBGROUP=NO.
BEGIN GPL
  SOURCE: s=userSource(id("graphdataset"))
  DATA: historicAvgSteps=col(source(s), name("__historicAvgSteps"))
  DATA: daysAchievedGoal=col(source(s), name("__daysAchievedGoal"), unit.category())
  DATA: Incentive_type=col(source(s), name("Incentive_type"), unit.category())
  GUIDE: axis(dim(1), label("$historicAvgSteps"))
  GUIDE: axis(dim(2), label("$daysAchievedGoal"))
  GUIDE: legend(aesthetic(aesthetic.color.interior), label("Incentive_type"))
  GUIDE: text.title(label("Scatter Plot of $daysAchievedGoal by $historicAvgSteps by ",
    "Incentive_type"))
  SCALE: cat(aesthetic(aesthetic.color.interior), include(
"1.00", "2.00"))
  ELEMENT: point(position(historicAvgSteps*daysAchievedGoal), color.interior(Incentive_type))
END GPL.

* Chart Builder.
GGRAPH
  /GRAPHDATASET NAME="graphdataset" VARIABLES=@$historicAvgSteps[name="__historicAvgSteps"] 
    @$daysAchievedGoal[name="__daysAchievedGoal"] Feedback_frame MISSING=LISTWISE REPORTMISSING=NO
  /GRAPHSPEC SOURCE=INLINE
  /FITLINE TOTAL=NO SUBGROUP=NO.
BEGIN GPL
  SOURCE: s=userSource(id("graphdataset"))
  DATA: historicAvgSteps=col(source(s), name("__historicAvgSteps"))
  DATA: daysAchievedGoal=col(source(s), name("__daysAchievedGoal"), unit.category())
  DATA: Feedback_frame=col(source(s), name("Feedback_frame"), unit.category())
  GUIDE: axis(dim(1), label("$historicAvgSteps"))
  GUIDE: axis(dim(2), label("$daysAchievedGoal"))
  GUIDE: legend(aesthetic(aesthetic.color.interior), label("Feedback_frame"))
  GUIDE: text.title(label("Scatter Plot of $daysAchievedGoal by $historicAvgSteps by ",
    "Feedback_frame"))
  SCALE: cat(aesthetic(aesthetic.color.interior), include(
"1.00", "2.00"))
  ELEMENT: point(position(historicAvgSteps*daysAchievedGoal), color.interior(Feedback_frame))
END GPL.

*repeat two-way ANOVA as non-parametric -> two times Kruskall wallis for the seperate factors
    
*Nonparametric Tests: Independent Samples. 
NPTESTS 
  /INDEPENDENT TEST (@$daysAchievedGoal) GROUP (Incentive_type) KRUSKAL_WALLIS(COMPARE=PAIRWISE) 
  /MISSING SCOPE=ANALYSIS USERMISSING=EXCLUDE
  /CRITERIA ALPHA=0.05  CILEVEL=95.


*Nonparametric Tests: Independent Samples. 
NPTESTS 
  /INDEPENDENT TEST (@$daysAchievedGoal) GROUP (Feedback_frame) KRUSKAL_WALLIS(COMPARE=PAIRWISE) 
  /MISSING SCOPE=ANALYSIS USERMISSING=EXCLUDE
  /CRITERIA ALPHA=0.05  CILEVEL=95.

*Exploratory analysis
    
*Q1Which factors predict uptake of a deposit contract?
    

    
*Exploring the predictors of uptake (met split file)
    
DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT groups = 1) AND (NOT @$stepGoal=10000).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

SORT CASES  BY Incentive_type.
SPLIT FILE LAYERED BY Incentive_type.

CROSSTABS
  /TABLES=Uptake_def BY Gender
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Whichofthecategoriesbelowdoyouselfidentifywith
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Howmuchmoneydoyouhaveavailable 
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ 
  /CELLS=COUNT
  /COUNT ROUND CELL.

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER AgeCorrected 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Baseline_Total_SE 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Risktaking 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Selfcontrol_scale 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).


*enter regression model

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER @$historicAvgSteps Whatgenderdoyouidentifywith  AgeCorrected Baseline_Total_SE 
    TSRQ_EXTRINSIC_TOTAL_subscale TSRQ_AUTO_subscale Selfcontrol_scale Risk_proneness 
  /CONTRAST (Whatgenderdoyouidentifywith )=Indicator
  /CRITERIA=PIN(.05) POUT(.10) ITERATE(20) CUT(.5).

*again but now with dummy variables for multi category categorical variables

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=ENTER Gender AgeCorrected @$historicAvgSteps Goal_type Selfcontrol_scale 
    Baseline_Total_SE TSRQ_EXTRINSIC_TOTAL_subscale TSRQ_AUTO_subscale Risk_proneness Income_1 Income_3 
    Income_4 Weight_1 Weight_2 Weight_3 Weight_4 Weight_5 
  /PRINT=CI(95)
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

*backward regression model

LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=FSTEP(COND) @$historicAvgSteps Whatgenderdoyouidentifywith  AgeCorrected 
    Baseline_Total_SE TSRQ_EXTRINSIC_TOTAL_subscale TSRQ_AUTO_subscale Selfcontrol_scale Risk_proneness     
  /CONTRAST (Whatgenderdoyouidentifywith )=Indicator
  /CRITERIA=PIN(.05) POUT(.10) ITERATE(20) CUT(.5).

*again but now with dummy variables for multi category categorical variables
    
LOGISTIC REGRESSION VARIABLES Uptake_def
  /METHOD=FSTEP(COND) Gender AgeCorrected @$historicAvgSteps Goal_type Selfcontrol_scale 
    Baseline_Total_SE TSRQ_EXTRINSIC_TOTAL_subscale TSRQ_AUTO_subscale Risk_proneness Income_1 Income_3 
    Income_4 Weight_1 Weight_2 Weight_3 Weight_4 Weight_5     
  /CONTRAST (Whatgenderdoyouidentifywith )=Indicator
  /CRITERIA=PIN(.05) POUT(.10) ITERATE(20) CUT(.5).

*Q2: What could be mediators of intervention effects?

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

* PROCESS Models here
    
*Q3: What could be moderators of intervention effects?

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*moderation by SE, Selfcontrol, risk taking, motivation

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH Baseline_Total_SE
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Baseline_Total_SE*Incentive_type Baseline_Total_SE*Feedback_frame.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH TSRQ_AUTO_subscale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE 
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Incentive_type*TSRQ_AUTO_subscale Feedback_frame*TSRQ_AUTO_subscale.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH TSRQ_EXTRINSIC_TOTAL_subscale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Incentive_type*TSRQ_EXTRINSIC_TOTAL_subscale Feedback_frame*TSRQ_EXTRINSIC_TOTAL_subscale.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH Selfcontrol_scale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type 
    Incentive_type*Selfcontrol_scale Feedback_frame*Selfcontrol_scale.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH Risk_proneness
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type Incentive_type*Risk_proneness 
    Feedback_frame*Risk_proneness.


*same as above but then with baseline steps as covariate added to model

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps 
    Baseline_Total_SE
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps 
    Baseline_Total_SE*Incentive_type Baseline_Total_SE*Feedback_frame.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps 
    TSRQ_AUTO_subscale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps 
    Feedback_frame*TSRQ_AUTO_subscale Incentive_type*TSRQ_AUTO_subscale.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps 
    TSRQ_EXTRINSIC_TOTAL_subscale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps 
    Incentive_type*TSRQ_EXTRINSIC_TOTAL_subscale Feedback_frame*TSRQ_EXTRINSIC_TOTAL_subscale.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps 
    Selfcontrol_scale
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps 
    Incentive_type*Selfcontrol_scale Feedback_frame*Selfcontrol_scale.

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps Risk_proneness
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=ZRESID COOK LEVER
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=RESIDUALS
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps 
    Feedback_frame*Risk_proneness Incentive_type*Risk_proneness.

*fruther explorting interaction by self-efficacy

*simple slopes plot for the interaction

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in control group

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=1). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


DATASET ACTIVATE DataSet1.
DESCRIPTIVES VARIABLES=Baseline_Total_SE
  /STATISTICS=MEAN STDDEV MIN MAX.


*median split self-efficacy to investigate interaction with incentive type

RECODE Baseline_Total_SE (Lowest thru 3.69=0) (3.7 thru Highest=1) INTO Baseline_Total_SE_median.
EXECUTE.

VALUE LABELS
Baseline_Total_SE_median
0 'low'
1 'high'.
EXECUTE.

UNIANOVA @$daysAchievedGoal BY Incentive_type Baseline_Total_SE_median
  /CONTRAST(Incentive_type)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PLOT=PROFILE(Incentive_type Incentive_type*Baseline_Total_SE_median Baseline_Total_SE_median) 
    TYPE=LINE ERRORBAR=NO MEANREFERENCE=NO YAXIS=AUTO
  /EMMEANS=TABLES(Baseline_Total_SE_median*Incentive_type) 
  /EMMEANS=TABLES(Baseline_Total_SE_median*Incentive_type) 
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Baseline_Total_SE_median Baseline_Total_SE_median*Incentive_type.


*reliability analysis for SEPA scale
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

DATASET ACTIVATE DataSet1.
RELIABILITY
  /VARIABLES=Selfefficacy_tired Selfefficacy_badmood Selfefficacy_donthavetime 
    Selfefficacy_vacation Selfefficacy_rainingsnowing
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.

RELIABILITY
  /VARIABLES=FINAL_Selfefficacy_tired FINAL_Selfefficacy_badmood FINAL_Selfefficacy_donthavetime 
    FINAL_Selfefficacy_vacation FINAL_Selfefficacy_rainingsnowing
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.

*reliability analysis of TRSQ
        
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


RELIABILITY
  /VARIABLES=TSRQ_AUTO1_responsibility TSRQ_AUTO2_bestformyhealth 
    TSRQ_AUTO3_carefullythoughtimportancelife TSRQ_AUTO4_importantchoice TSRQ_AUTO5_consistentlifegoals 
    TSRQ_AUTO6_importanttolivehealthy
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.

RELIABILITY
  /VARIABLES=TSRQ_INTRO1_guiltyashemed TSRQ_EXREWARD1_earnrewards TSRQ_EXSOCIAL1_upsetothers 
    TSRQ_EXREWARD2_asmuchrewardsaspossible TSRQ_INTRO2_feelbad TSRQ_EXREWARD3_angrynotgettingrewards 
    TSRQ_EXSOCIAL2_pressureothers TSRQ_EXREWARD4_pressurerewards TSRQ_EXSOCIAL3_approvalothers 
    TSRQ_EXREWARD5_proudforearningrewards TSRQ_EXSOCIAL4_showothersicandoit 
    TSRQ_EXREWARD6_earndrewardstoshowotherssicandoit TSRQ_EXMEDS_reducemeds
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.


RELIABILITY
  /VARIABLES=FINAL_TSRQ_AUTO1_responsibility FINAL_TSRQ_AUTO2_bestformyhealth 
    FINAL_TSRQ_AUTO3_carefullythoughtimportancelife FINAL_TSRQ_AUTO4_importantchoice 
    FINAL_TSRQ_AUTO5_consistentlifegoals FINAL_TSRQ_AUTO6_importanttolivehealthy
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.

RELIABILITY
  /VARIABLES=FINAL_TSRQ_INTRO1_guiltyashemed FINAL_TSRQ_EXREWARD1_earnrewards 
    FINAL_TSRQ_EXSOCIAL1_upsetothers FINAL_TSRQ_EXREWARD2_asmuchrewardsaspossible 
    FINAL_TSRQ_INTRO2_feelbad FINAL_TSRQ_EXREWARD3_angrynotgettingrewards 
    FINAL_TSRQ_EXSOCIAL2_pressureothers FINAL_TSRQ_EXREWARD4_pressurerewards 
    FINAL_TSRQ_EXSOCIAL3_approvalothers FINAL_TSRQ_EXREWARD5_proudforearningrewards 
    FINAL_TSRQ_EXSOCIAL4_showothersicandoit FINAL_TSRQ_EXREWARD6_earndrewardstoshowotherssicandoit 
    FINAL_TSRQ_EXMEDS_reducemeds
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.


*reliability of selfinvented self-control scale
    

RELIABILITY
  /VARIABLES=I_need_extra_commitment Trouble_sticking_health_goals 
    Sticking_to_newyearsresolutions_recoded
  /SCALE('ALL VARIABLES') ALL
  /MODEL=ALPHA
  /STATISTICS=DESCRIPTIVE SCALE
  /SUMMARY=TOTAL.



************************************************************Selections***********************************************

* Select all who onboarded AND Finished baseline

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT(sysmis(TSRQ_EXMEDS_reducemeds))).
VARIABLE LABELS filter_$ 'NOT(sysmis(TSRQ_EXMEDS_reducemeds)) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

* Select all who onboarded AND Finished baseline AND EXPLICITLY accepted intervention

USE ALL.
COMPUTE filter_$=(NOT(sysmis(TSRQ_EXMEDS_reducemeds)) and NOT Uptakecheck=3).
VARIABLE LABELS filter_$ 'NOT(sysmis(TSRQ_EXMEDS_reducemeds)) and NOT Uptakecheck=3 (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

* Select all who onboarded AND Finished baseline AND EXPLICITLY accepted intervention AND those who did not pay the deposit (payment pending status)


USE ALL.
COMPUTE filter_$=(NOT(sysmis(TSRQ_EXMEDS_reducemeds)) and NOT Uptakecheck=3 and NOT Studyphase=4).
VARIABLE LABELS filter_$ 'NOT(sysmis(TSRQ_EXMEDS_reducemeds)) and NOT Uptakecheck=3 and NOT '+
    'Studyphase=4 (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.
 
* Select all who onboarded AND Finished baseline AND EXPLICITLY accepted intervention AND those who did not pay the deposit (payment pending status) AND who started the intervention (adherent at at least 1 day)

USE ALL.
COMPUTE filter_$=(NOT(sysmis(TSRQ_EXMEDS_reducemeds)) and NOT Uptakecheck=3 and NOT Studyphase=4 
    and AdherentDays > 0).
VARIABLE LABELS filter_$ 'NOT(sysmis(TSRQ_EXMEDS_reducemeds)) and NOT Uptakecheck=3 and NOT '+
    'Studyphase=4 and AdherentDays > 0 (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

* Select all who finished all intervention days (stepslog contains day 20)

*DID NOT FIGURE THIS OUT YET (!)

* Select all who finished final survey

USE ALL.
COMPUTE filter_$=(NOT(sysmis(FINAL_TSRQ_EXMEDS_reducemeds)) ).
VARIABLE LABELS filter_$ 'NOT(sysmis(FINAL_TSRQ_EXMEDS_reducemeds))  (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

* Select all who finished final survey + who received a tailored step goal

USE ALL.
COMPUTE filter_$=(NOT(sysmis(FINAL_TSRQ_EXMEDS_reducemeds)) and NOT @$stepGoal=10000).
VARIABLE LABELS filter_$ 'NOT(sysmis(FINAL_TSRQ_EXMEDS_reducemeds)) and NOT @$stepGoal=10000 '+
    '(FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*select all who finished the baseline survey + exclude 2 persons over 30 years of age

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*select all who finished the baseline survey + exclude 2 persons over 30 years of age + who were in deposit condition

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (groups=3) OR (groups=5).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps)

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in control group

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=1). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in reward groups

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=2) and (NOT groups=4). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


























*the interaction between SE and incentivet ype
    
   
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in control group

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=1). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*mean centering the IV and moderator first
    
DESCRIPTIVES VARIABLES=Baseline_Total_SE
  /STATISTICS=MEAN STDDEV MIN MAX.

COMPUTE C_Baseline_Total_SE=Baseline_Total_SE-3.7064.
EXECUTE.

if Incentive_type = 1 AIncentive_type = 2.
if Incentive_type = 2 AIncentive_type = 1.

*run full model with interaction 
    
DATASET ACTIVATE DataSet1.
UNIANOVA @$daysAchievedGoal BY Incentive_type WITH Baseline_Total_SE
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT ETASQ DESCRIPTIVE PARAMETER
  /CRITERIA=ALPHA(.05)
  /DESIGN=Baseline_Total_SE Incentive_type Incentive_type*Baseline_Total_SE.

DATASET ACTIVATE DataSet1.
UNIANOVA @$daysAchievedGoal BY AIncentive_type WITH Baseline_Total_SE
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT ETASQ DESCRIPTIVE PARAMETER
  /CRITERIA=ALPHA(.05)
  /DESIGN=Baseline_Total_SE AIncentive_type AIncentive_type*Baseline_Total_SE.

*same thing but then by using split file

SORT CASES  BY Incentive_type.
SPLIT FILE LAYERED BY Incentive_type.

REGRESSION
  /MISSING LISTWISE
  /STATISTICS COEFF OUTS R ANOVA
  /CRITERIA=PIN(.05) POUT(.10)
  /NOORIGIN 
  /DEPENDENT @$daysAchievedGoal
  /METHOD=ENTER Baseline_Total_SE.







*exploratory analysis 18-11-2021
    
*determine differences between uptakers and non-uptakers of deposits
    
*select all who finished the baseline survey + exclude 2 persons over 30 years of age + who were in deposit condition

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (groups=3) OR (groups=5).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

GLM Selfcontrol_scale Baseline_Total_SE AgeCorrected TSRQ_AUTO_subscale 
    TSRQ_EXTRINSIC_TOTAL_subscale @$historicAvgSteps @$daysAchievedGoal BY Uptake_def
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT=DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN= Uptake_def.


*determine which baseline factors are related to overall intervention effectiveness in incentive conditions
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in control group

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT groups=1). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


DATASET ACTIVATE DataSet1.
CORRELATIONS
  /VARIABLES=@$daysAchievedGoal Selfcontrol_scale Baseline_Total_SE AgeCorrected TSRQ_AUTO_subscale 
    TSRQ_EXTRINSIC_TOTAL_subscale @$historicAvgSteps
  /PRINT=TWOTAIL NOSIG FULL
  /STATISTICS DESCRIPTIVES
  /MISSING=PAIRWISE.


*Sensitivity checks 18-11-2021
    

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


FREQUENCIES VARIABLES=Cheat Exams Aware_others Discuss_others Participate_again 
    Carried_smartphone_moreoften
  /ORDER=ANALYSIS.

*t-tests for cheating and contamination
    
T-TEST GROUPS=Cheat(2 3)
  /MISSING=ANALYSIS
  /VARIABLES=@$daysAchievedGoal
  /ES DISPLAY(TRUE)
  /CRITERIA=CI(.95).

T-TEST GROUPS=Aware_others(2 3)
  /MISSING=ANALYSIS
  /VARIABLES=@$daysAchievedGoal
  /ES DISPLAY(TRUE)
  /CRITERIA=CI(.95).


*correlations for smartphone use and GAD-7
 
CORRELATIONS
  /VARIABLES=GAD7_Total Carried_smartphone_moreoften @$daysAchievedGoal
  /PRINT=TWOTAIL NOSIG FULL
  /STATISTICS DESCRIPTIVES
  /MISSING=PAIRWISE.

*rerun main analysis withouth cheaters
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal and who did not cheat

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) and (NOT Cheat = 3). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*ANOVA with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Groups WITH @$historicAvgSteps
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Groups.

*2-way ANOVA with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.


*t-test to investigate if carrying smartphone more often is related to incentive type
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.
    

T-TEST GROUPS=Incentive_type(1 2)
  /MISSING=ANALYSIS
  /VARIABLES=Carried_smartphone_moreoften
  /ES DISPLAY(TRUE)
  /CRITERIA=CI(.95).

*correlation between carrying smartphone and goal achievement in control condition
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal and control condition only

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000) AND (groups=1).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.
    
*manipulation check
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*run two-way anova with loss feelings as DV
   
DATASET ACTIVATE DataSet1.
UNIANOVA Felt_losingmoney BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
 /PRINT ETASQ DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Incentive_type*Feedback_frame. 

    
*run two-way anova with goal commitment as DV
    
UNIANOVA Committed_increase_mystepcount BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
 /PRINT ETASQ DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Incentive_type*Feedback_frame.

*explore whether incentive type and feedback frame impacted smartphone carrying frequency
   
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

DATASET ACTIVATE DataSet1.
UNIANOVA Carried_smartphone_moreoften BY Incentive_type Feedback_frame
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
 /PRINT ETASQ DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Incentive_type*Feedback_frame. 























*exploratory analyses for revision of paper on 12 jan 2022
    
*Hypothesis 1: deposit contract conditions will have lower uptake 

*Chi square for uptake 

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

CROSSTABS
  /TABLES=Uptake_def BY Incentive_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Feedback_frame
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.


DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT @$stepGoal=10000).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


CROSSTABS
  /TABLES=Uptake_def BY Incentive_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Feedback_frame
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (@$stepGoal=10000).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


CROSSTABS
  /TABLES=Uptake_def BY Incentive_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Feedback_frame
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI 
  /CELLS=COUNT COLUMN TOTAL 
  /COUNT ROUND CELL.

*2-way ANOVA with Baseline steps as covariate

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (@$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


UNIANOVA @$daysAchievedGoal BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.



*2-way ANOVA with Baseline steps as covariate on DV raw step count during intervention
    
DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

UNIANOVA @$averageSteps BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


UNIANOVA @$averageSteps BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (@$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


UNIANOVA @$averageSteps BY Incentive_type Feedback_frame WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Incentive_type) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Feedback_frame) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=Incentive_type Feedback_frame Feedback_frame*Incentive_type @$historicAvgSteps.



*1-way ANOVAS to test contrasts (with Baseline steps as covariate) on DV goals achieved
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

DATASET ACTIVATE DataSet1.
UNIANOVA @$daysAchievedGoal BY Control_vs_Reward WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Control_vs_Reward) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Reward.

UNIANOVA @$daysAchievedGoal BY Control_vs_Deposit WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Deposit.

UNIANOVA @$daysAchievedGoal BY Control_vs_Gain WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Gain.

UNIANOVA @$daysAchievedGoal BY Control_vs_Loss WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Loss.


*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


DATASET ACTIVATE DataSet1.
UNIANOVA @$daysAchievedGoal BY Control_vs_Reward WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Control_vs_Reward) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Reward.

UNIANOVA @$daysAchievedGoal BY Control_vs_Deposit WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Deposit.

UNIANOVA @$daysAchievedGoal BY Control_vs_Gain WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Gain.

UNIANOVA @$daysAchievedGoal BY Control_vs_Loss WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Loss.

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (@$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


DATASET ACTIVATE DataSet1.
UNIANOVA @$daysAchievedGoal BY Control_vs_Reward WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Control_vs_Reward) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Reward.

UNIANOVA @$daysAchievedGoal BY Control_vs_Deposit WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Deposit.

UNIANOVA @$daysAchievedGoal BY Control_vs_Gain WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Gain.

UNIANOVA @$daysAchievedGoal BY Control_vs_Loss WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Control_vs_Loss.


*overall intervention vs control
    

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


UNIANOVA @$daysAchievedGoal BY Intervention_vs_control WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Intervention_vs_control.


DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

UNIANOVA @$daysAchievedGoal BY Intervention_vs_control WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Intervention_vs_control.


DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (@$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

UNIANOVA @$daysAchievedGoal BY Intervention_vs_control WITH @$historicAvgSteps
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=PRED SEPRED RESID ZRESID
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Intervention_vs_control.


*effect of goals on effectiveness
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) 

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

UNIANOVA @$stepGoal BY Goal_type
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT ETASQ DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Goal_type.

UNIANOVA @$daysAchievedGoal BY Goal_type
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT ETASQ DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Goal_type.


*Hypothesis 2: All four groups that receive a financial incentive will have higher effectiveness than the no-incentive control group

*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*ANOVA with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Groups WITH @$historicAvgSteps
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Groups.


DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


*ANOVA with Baseline steps as covariate

UNIANOVA @$daysAchievedGoal BY Groups WITH @$historicAvgSteps
  /CONTRAST(Groups)=Simple(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /SAVE=SEPRED ZRESID COOK LEVER
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /EMMEANS=TABLES(Groups) WITH(@$historicAvgSteps=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE HOMOGENEITY
  /PLOT=SPREADLEVEL
  /CRITERIA=ALPHA(.05)
  /DESIGN=@$historicAvgSteps Groups.










*exploratory analysis 28-01-2022
    
*determine differences between those with default goals and tailored goals
    
*Exploring the predictors of uptake (over alle condities zonder split file)

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT groups = 1).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

CROSSTABS
  /TABLES=Goal_type BY Gender
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Goal_type BY Whichofthecategoriesbelowdoyouselfidentifywith
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Goal_type BY Howmuchmoneydoyouhaveavailable 
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI
  /CELLS=COUNT
  /COUNT ROUND CELL.

CROSSTABS
  /TABLES=Uptake_def BY Goal_type
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ PHI
  /CELLS=COUNT
  /COUNT ROUND CELL.

LOGISTIC REGRESSION VARIABLES Goal_type
  /METHOD=ENTER AgeCorrected 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).


LOGISTIC REGRESSION VARIABLES Goal_type
  /METHOD=ENTER Baseline_Total_SE 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Goal_type
  /METHOD=ENTER Risktaking 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).


LOGISTIC REGRESSION VARIABLES Goal_type
  /METHOD=ENTER Selfcontrol_scale 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Goal_type
  /METHOD=ENTER TSRQ_AUTO_subscale 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Goal_type
  /METHOD=ENTER TSRQ_EXTRINSIC_TOTAL_subscale 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).

LOGISTIC REGRESSION VARIABLES Goal_type
  /METHOD=ENTER @$historicAvgSteps 
  /CLASSPLOT
  /PRINT=GOODFIT
  /CRITERIA=PIN(0.05) POUT(0.10) ITERATE(20) CUT(0.5).



***revision analyses 220714

*select all who finished baseline and are within the age range 

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

*descriptives per condition

DATASET ACTIVATE DataSet1.
SORT CASES  BY Group.
SPLIT FILE LAYERED BY Group.

FREQUENCIES VARIABLES=@$platform
  /ORDER=ANALYSIS.


*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal AND who were not in control group

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


*step goal for 126 full sample
    

*select all who finished baseline and are within the age range 

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990).
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.

SPLIT FILE OFF.


DATASET ACTIVATE DataSet1.
DESCRIPTIVES VARIABLES=@$stepGoal
  /STATISTICS=MEAN STDDEV MIN MAX.

*descriptives per condition

DATASET ACTIVATE DataSet1.
SORT CASES  BY Group.
SPLIT FILE LAYERED BY Group.


DATASET ACTIVATE DataSet1.
SORT CASES  BY Group.
SPLIT FILE LAYERED BY Group.


DATASET ACTIVATE DataSet1.
DESCRIPTIVES VARIABLES=@$stepGoal
  /STATISTICS=MEAN STDDEV MIN MAX.

*test if step goal differed at start of intervention
    
UNIANOVA @$stepGoal BY Group
  /CONTRAST(Group)=Deviation(1)
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /PRINT DESCRIPTIVE
  /CRITERIA=ALPHA(.05)
  /DESIGN=Group.

*update of demographics table
    
*select all who finished baseline, are within the age range and who took up intervention and who did not have an empty steps log (>1 day of valid steps) AND who received tailored goal 

DATASET ACTIVATE DataSet1.
USE ALL.
COMPUTE filter_$=(NOT sysmis(TSRQ_EXMEDS_reducemeds)) AND (Whatisyourbirthyear  >= 1990) AND (NOT(ID=38)) AND (NOT(ID=42)) AND (NOT(ID=66)) AND (NOT(ID=104)) AND (NOT(ID=32)) AND (NOT(ID=43)) AND (NOT(ID=109)) AND (NOT(ID=111)) 
AND (NOT(ID=114)) AND (NOT(ID=122)) AND (NOT(ID=124)) AND (NOT(ID=22)) AND (NOT(ID=33)) AND (NOT(ID=65)) AND (NOT(ID=90)) AND (NOT(ID=1)) AND (NOT(ID=17)) AND (NOT(ID=118)) AND (NOT(ID=12)) AND (NOT(ID=108)) AND (NOT(ID=70)) AND 
(NOT(ID=116)) AND (NOT(ID=121)) AND (NOT(ID=83)) AND (NOT(ID=44)) AND (NOT(ID=40)) AND (NOT(ID=24)) AND (NOT(ID=30)) AND (NOT(ID=10)) AND (NOT(ID=11)) and (NOT @$stepGoal = 10000). 
VARIABLE LABELS filter_$ 'NOT sysmis(TSRQ_EXMEDS_reducemeds) (FILTER)'.
VALUE LABELS filter_$ 0 'Not Selected' 1 'Selected'.
FORMATS filter_$ (f1.0).
FILTER BY filter_$.
EXECUTE.


DESCRIPTIVES VARIABLES=AgeCorrected Gender Nationality Study_work_status Money_available 
    Subjective_weight_status
  /STATISTICS=MEAN STDDEV MIN MAX.

FREQUENCIES VARIABLES=Gender Nationality Study_work_status Money_available Subjective_weight_status
  /STATISTICS=STDDEV MEAN
  /ORDER=ANALYSIS.
