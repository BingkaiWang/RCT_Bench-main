﻿*$Rev: 121017 $ all 2.
SET UNICODE=ON.
SHOW LOCALE.
PRESERVE LOCALE.
SET LOCALE='en_UK'.
GET DATA
 /TYPE=TXT
 /FILE='survey_262428_SPSS_data_file.dat'
 /DELCASE=LINE
 /DELIMITERS=","
 /QUALIFIER="'"
 /ARRANGEMENT=DELIMITED
 /FIRSTCASE=1
 /IMPORTCASE=ALL
 /VARIABLES=
 V1 F7
 V2 DATETIME23.2
 V3 F7
 V4 A20
 V5 A31
 V6 DATETIME23.2
 V7 DATETIME23.2
 V8 A66
 V9 A2
 V10 A2
 V11 A3
 V12 A3
 V13 A3
 V14 A2
 V15 A3
 V16 A3
 V17 A3
 V18 A3
 V19 A3
 V20 A3
 V21 A3
 V22 A3
 V23 A3
 V24 A3
 V25 A2
 V26 A2
 V27 A2
 V28 A2
 V29 A2
 V30 A165
 V31 A2
 V32 A2
 V33 A2
 V34 A2
 V35 A2
 V36 A2
 V37 A2
 V38 A2
 V39 A2
 V40 A2
 V41 A2
 V42 A2
 V43 F1.0
 V44 F2.0
 V45 A2
 V46 F1.0
 V47 F2.0
 V48 A2
 V49 F1.0
 V50 F2.0
 V51 F2.0
 V52 F2.0
 V53 A2
 V54 A2
 V55 A2
 V56 A2
 V57 A2
 V58 A2
 V59 A2
 V60 A2
 V61 A2
 V62 A2
 V63 A2
 V64 A2
 V65 A2
 V66 A2
 V67 A2
 V68 A2
 V69 A2
 V70 A2
 V71 A2
 V72 A2
 V73 A2
 V74 A2
 V75 A2
 V76 A2.
CACHE.
EXECUTE.
*Define Variable Properties.
VARIABLE LABELS V1 "id".
VARIABLE LABELS V2 "submitdate".
VARIABLE LABELS V3 "lastpage".
VARIABLE LABELS V4 "startlanguage".
VARIABLE LABELS V5 "Seed".
VARIABLE LABELS V6 "startdate".
VARIABLE LABELS V7 "datestamp".
VARIABLE LABELS V8 "participantCode".
VARIABLE LABELS V9 "How frequently have you checked your stepcount in the previous 20 days?".
VARIABLE LABELS V10 "How frequently have you checked how close you were to achieving your step goal in the past 20 days?".
VARIABLE LABELS V11 "[I felt that I was losing money if I did not increase my step count] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the v"+
"alue 10 means: ‘totally agree’".
VARIABLE LABELS V12 "[I felt strongly committed to the goal of increasing my step count] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the va"+
"lue 10 means: ‘totally agree’".
VARIABLE LABELS V13 "[Because I participated in this study I chose to carry my smartphone more with me than I would normally do ] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the val"+
"ue 1 means: ‘totally disagree’ and the value 10 means: ‘totally agree’".
VARIABLE LABELS V14 "Did you cheat the system in any way (do not worry, you will receive your incentive as promised, independent of your answer to this question) ?".
VARIABLE LABELS V15 "[The intervention was fair] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally agree’".
VARIABLE LABELS V16 "[The intervention was fun] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally agree’".
VARIABLE LABELS V17 "[The intervention was helpful] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally agree’".
VARIABLE LABELS V18 "[The intervention was easy to use] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally agree’".
VARIABLE LABELS V19 "[The intervention was convenient] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally agree’".
VARIABLE LABELS V20 "[The intervention was acceptable] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally agree’".
VARIABLE LABELS V21 "[I would recommend the intervention to others] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally agre"+
"e’".
VARIABLE LABELS V22 "[I liked monitoring my steps with the intervention] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally"+
" agree’".
VARIABLE LABELS V23 "[I liked earning rewards with the intervention] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘totally agr"+
"ee’".
VARIABLE LABELS V24 "[The rewards helped increase my steps in the intervention] Please indicate to what extent you agree with the statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’ and the value 10 means: ‘"+
"totally agree’".
VARIABLE LABELS V25 "Would you like to participate in the same intervention for another 3 weeks?".
VARIABLE LABELS V26 "Did you have exams during the intervention period of this study? ".
VARIABLE LABELS V27 "Did you know other people who were also participating in this experiment? ".
VARIABLE LABELS V28 "Did you discuss the experiment with them? ".
VARIABLE LABELS V29 "Did you know about what they were required to do for the study? ".
VARIABLE LABELS V30 "Could you please write down what the other participant(s) were required to do in the experiment? ".
VARIABLE LABELS V31 "Did you experience flu-like symptoms like fever, coughing and/or trouble breathing during the intervention period of this study?".
VARIABLE LABELS V32 "Did you engage in less physical activity due to these symptoms?".
VARIABLE LABELS V33 "Did you engage in less physical activity than usual due to the current situation with regard to the Corona-virus?".
VARIABLE LABELS V34 "[Feeling nervous, anxious or on edge] Over the last three weeks, how often have you been bothered by the following problems? ".
VARIABLE LABELS V35 "[Not being able to stop or control worrying	] Over the last three weeks, how often have you been bothered by the following problems? ".
VARIABLE LABELS V36 "[Worrying too much about different things] Over the last three weeks, how often have you been bothered by the following problems? ".
VARIABLE LABELS V37 "[Trouble relaxing] Over the last three weeks, how often have you been bothered by the following problems? ".
VARIABLE LABELS V38 "[Being so restless that it is hard to sit still] Over the last three weeks, how often have you been bothered by the following problems? ".
VARIABLE LABELS V39 "[Becoming easily annoyed or irritable] Over the last three weeks, how often have you been bothered by the following problems? ".
VARIABLE LABELS V40 "[Feeling afraid as if something awful might happen ] Over the last three weeks, how often have you been bothered by the following problems? ".
VARIABLE LABELS V41 "If you checked off any problems, how difficult have these problems made it for you to do your work, take care of things at home or get along with other people? ".
VARIABLE LABELS V42 "We are interested in finding out about the kinds of physical activities that people do as part of their everyday lives. The next questions will ask you about the time you spent being physically active in the last 7 days. Please "+
"answer each question even if you do not consider yourself to be an active person. Please think about the activities you do at work, as part of your house and yard work, to get from place to place, and in your spare time for recr"+
"eation, exercise or sport.     Think about all the vigorous activities that you did in the last 7 days. Vigorous physical activities refer to activities that take hard physical effort and make you breathe much harder than normal"+
". Think only about those physical activities that you did for at least 10 minutes at a time.     During the last 7 days, on how many days did you do vigorous physical activities like heavy lifting, digging, aerobics, or fast bic"+
"ycling?".
VARIABLE LABELS V43 "[Hours per day] How much time did you usually spend doing vigorous physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for 'm"+
"inutes'.".
VARIABLE LABELS V44 "[Minutes per day] How much time did you usually spend doing vigorous physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for "+
"'minutes'.".
VARIABLE LABELS V45 "Think about all the moderate activities that you did in the last 7 days. Moderate activities refer to activities that take moderate physical effort and make you breathe somewhat harder than normal. Think only about those physica"+
"l activities that you did for at least 10 minutes at a time.     During the last 7 days, on how many days did you do moderate physical activities like carrying light loads, bicycling at a regular pace, or doubles tennis? Do not "+
"include walking.".
VARIABLE LABELS V46 "[Hours per day] How much time did you usually spend doing moderate physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for 'm"+
"inutes'.".
VARIABLE LABELS V47 "[Minutes per day] How much time did you usually spend doing moderate physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for "+
"'minutes'.".
VARIABLE LABELS V48 "Think about the time you spent walking in the last 7 days. This includes at work and at home, walking to travel from place to place, and any other walking that you have done solely for recreation, sport, exercise, or leisure.   "+
"  During the last 7 days, on how many days did you walk for at least 10 minutes at a time?".
VARIABLE LABELS V49 "[Hours per day] How much time did you usually spend walking on one of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V50 "[Minutes per day] How much time did you usually spend walking on one of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V51 "[Hours per day] The last question is about the time you spent sitting on weekdays during the last 7 days. Include time spent at work, at home, while doing course work and during leisure time. This may include time spent sitting "+
"at a desk, visiting friends, reading, or sitting or lying down to watch television.     During the last 7 days, how much time did you spend sitting on a week day? As an example: if you sat for 8,5 hours. Please fill in '8' in th"+
"e box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V52 "[Minutes per day] The last question is about the time you spent sitting on weekdays during the last 7 days. Include time spent at work, at home, while doing course work and during leisure time. This may include time spent sittin"+
"g at a desk, visiting friends, reading, or sitting or lying down to watch television.     During the last 7 days, how much time did you spend sitting on a week day? As an example: if you sat for 8,5 hours. Please fill in '8' in "+
"the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V53 "[I am confident that I can participate in regular exercise when I am tired] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select that opt"+
"ion   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V54 "[I am confident that I can participate in regular exercise when I am in a bad mood] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select "+
"that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V55 "[I am confident that I can participate in regular exercise when I feel I don’t have the time] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you c"+
"an select that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V56 "[I am confident that I can participate in regular exercise when I am on vacation] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select th"+
"at option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V57 "[I am confident that I can participate in regular exercise when it is raining or snowing.] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can "+
"select that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V58 "[Because I feel that I want to take responsibility for my own health ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements "+
"related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V59 "[Because I would feel guilty or ashamed of myself I did not do it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rela"+
"ted to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V60 "[Because I know I can earn rewards for doing it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving y"+
"our goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V61 "[Because I personally believe it is the best thing for my health ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rela"+
"ted to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V62 "[Because others would be upset with me if I did not do it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to a"+
"chieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V63 "[Because I want to earn as much rewards as possible] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achievi"+
"ng your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V64 "[Because I have carefully thought about it and believe being physically active is very important for many aspects of my life ] You are almost done. This is the final page with questions.     We want to know what drives you to be"+
" more physically active. Below you will find statements related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V65 "[Because I would feel bad about myself if I did not do it	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to "+
"achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V66 "[Because I would be angry at myself if I did not get the rewards] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements relat"+
"ed to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V67 "[Because being physically active is an important choice I really want to make ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find st"+
"atements related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V68 "[Because I feel pressure from others to do this] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving y"+
"our goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V69 "[Because I feel pressure from the rewards to do this] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achiev"+
"ing your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V70 "[Because being physically active is consistent with my life goals ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rel"+
"ated to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V71 "[Because I want others to approve of me 	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving your go"+
"als. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V72 "[Because I want to be proud of myself for earning the rewards	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related"+
" to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V73 "[Because it is very important to live as healthily as possible] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related"+
" to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V74 "[Because I want others to see I can do it ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving your g"+
"oals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V75 "[Because I want to earn rewards to show others I can do it	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to"+
" achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V76 "[Because being physically active would allow me to reduce my medication use] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find state"+
"ments related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
*Define Value labels.
VALUE LABELS  V9
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day"
 "A5" "5 = Many times a day".
VALUE LABELS  V10
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day"
 "A5" "5 = Many times a day".
VALUE LABELS  V11
 "A0" "Does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V12
 "A0" "Does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V13
 "A0" "Does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V14
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V15
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V16
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V17
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V18
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V19
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V20
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V21
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V22
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V23
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V24
 "A0" "This does not apply"
 "A1" "1 = totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = totally agree".
VALUE LABELS  V25
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V26
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V27
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V28
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V29
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V31
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V32
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V33
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V34
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day".
VALUE LABELS  V35
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day".
VALUE LABELS  V36
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day".
VALUE LABELS  V37
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day".
VALUE LABELS  V38
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day".
VALUE LABELS  V39
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day".
VALUE LABELS  V40
 "A1" "1 = Not at all"
 "A2" "2 = Several days"
 "A3" "3 = More than half the days"
 "A4" "4 = Nearly every day".
VALUE LABELS  V41
 "A0" "This does not apply"
 "A1" "1 = Not difficult at all"
 "A2" "2 = Somewhat difficult"
 "A3" "3 = Very difficult"
 "A4" "4 = Extremely difficult".
VALUE LABELS  V42
 "A0" "No vigorous physical activities"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V45
 "A0" "No moderate physical activities"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V48
 "A0" "No walking"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V53
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V54
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V55
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V56
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V57
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V58
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V59
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V60
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V61
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V62
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V63
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V64
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V65
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V66
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V67
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V68
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V69
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V70
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V71
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V72
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V73
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V74
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V75
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V76
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
RENAME VARIABLE ( V1 = id ).
RENAME VARIABLE ( V2 = submitdate ).
RENAME VARIABLE ( V3 = lastpage ).
RENAME VARIABLE ( V4 = startlanguage ).
* Variable name was incorrect and was changed from  to q_ .
RENAME VARIABLE ( V5 = q_ ).
RENAME VARIABLE ( V6 = startdate ).
RENAME VARIABLE ( V7 = datestamp ).
RENAME VARIABLE ( V8 = participantCode ).
RENAME VARIABLE ( V9 = Q01 ).
RENAME VARIABLE ( V10 = Q02 ).
RENAME VARIABLE ( V11 = Q03_SQ1 ).
RENAME VARIABLE ( V12 = Q03_SQ2 ).
RENAME VARIABLE ( V13 = Q03_SQ3 ).
RENAME VARIABLE ( V14 = Q04 ).
RENAME VARIABLE ( V15 = Q05_SQ1 ).
RENAME VARIABLE ( V16 = Q05_SQ2 ).
RENAME VARIABLE ( V17 = Q05_SQ3 ).
RENAME VARIABLE ( V18 = Q05_SQ4 ).
RENAME VARIABLE ( V19 = Q05_SQ5 ).
RENAME VARIABLE ( V20 = Q05_SQ6 ).
RENAME VARIABLE ( V21 = Q05_SQ7 ).
RENAME VARIABLE ( V22 = Q05_SQ8 ).
RENAME VARIABLE ( V23 = Q05_SQ9 ).
RENAME VARIABLE ( V24 = Q05_SQ10 ).
RENAME VARIABLE ( V25 = Q06 ).
RENAME VARIABLE ( V26 = Q21 ).
RENAME VARIABLE ( V27 = Q07 ).
RENAME VARIABLE ( V28 = Q08 ).
RENAME VARIABLE ( V29 = Q09 ).
RENAME VARIABLE ( V30 = Q10 ).
RENAME VARIABLE ( V31 = Q27 ).
RENAME VARIABLE ( V32 = Q28 ).
RENAME VARIABLE ( V33 = Q29 ).
RENAME VARIABLE ( V34 = Q25_SQ1 ).
RENAME VARIABLE ( V35 = Q25_SQ2 ).
RENAME VARIABLE ( V36 = Q25_SQ3 ).
RENAME VARIABLE ( V37 = Q25_SQ4 ).
RENAME VARIABLE ( V38 = Q25_SQ5 ).
RENAME VARIABLE ( V39 = Q25_SQ6 ).
RENAME VARIABLE ( V40 = Q25_SQ7 ).
RENAME VARIABLE ( V41 = Q26 ).
RENAME VARIABLE ( V42 = Q11 ).
RENAME VARIABLE ( V43 = Q12_SQ1 ).
RENAME VARIABLE ( V44 = Q12_SQ2 ).
RENAME VARIABLE ( V45 = Q13 ).
RENAME VARIABLE ( V46 = Q14_SQ1 ).
RENAME VARIABLE ( V47 = Q14_SQ2 ).
RENAME VARIABLE ( V48 = Q15 ).
RENAME VARIABLE ( V49 = Q16_SQ1 ).
RENAME VARIABLE ( V50 = Q16_SQ2 ).
RENAME VARIABLE ( V51 = Q17_SQ1 ).
RENAME VARIABLE ( V52 = Q17_SQ2 ).
RENAME VARIABLE ( V53 = Q22_SQ1 ).
RENAME VARIABLE ( V54 = Q22_SQ2 ).
RENAME VARIABLE ( V55 = Q22_SQ3 ).
RENAME VARIABLE ( V56 = Q22_SQ4 ).
RENAME VARIABLE ( V57 = Q22_SQ5 ).
RENAME VARIABLE ( V58 = Q20_SQ1 ).
RENAME VARIABLE ( V59 = Q20_SQ2 ).
RENAME VARIABLE ( V60 = Q20_SQ3 ).
RENAME VARIABLE ( V61 = Q20_SQ4 ).
RENAME VARIABLE ( V62 = Q20_SQ5 ).
RENAME VARIABLE ( V63 = Q20_SQ6 ).
RENAME VARIABLE ( V64 = Q20_SQ7 ).
RENAME VARIABLE ( V65 = Q20_SQ8 ).
RENAME VARIABLE ( V66 = Q20_SQ9 ).
RENAME VARIABLE ( V67 = Q20_SQ10 ).
RENAME VARIABLE ( V68 = Q20_SQ11 ).
RENAME VARIABLE ( V69 = Q20_SQ12 ).
RENAME VARIABLE ( V70 = Q20_SQ13 ).
RENAME VARIABLE ( V71 = Q20_SQ14 ).
RENAME VARIABLE ( V72 = Q20_SQ15 ).
RENAME VARIABLE ( V73 = Q20_SQ16 ).
RENAME VARIABLE ( V74 = Q20_SQ17 ).
RENAME VARIABLE ( V75 = Q20_SQ18 ).
RENAME VARIABLE ( V76 = Q20_SQ19 ).
RESTORE LOCALE.
