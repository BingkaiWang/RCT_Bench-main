﻿*$Rev: 121017 $ all 2.
SET UNICODE=ON.
SHOW LOCALE.
PRESERVE LOCALE.
SET LOCALE='en_UK'.
GET DATA
 /TYPE=TXT
 /FILE='survey_662455_SPSS_data_file.dat'
 /DELCASE=LINE
 /DELIMITERS=","
 /QUALIFIER="'"
 /ARRANGEMENT=DELIMITED
 /FIRSTCASE=1
 /IMPORTCASE=ALL
 /VARIABLES=
 V1 F7
 V2 DATETIME23.2
 V3 F7
 V4 A20
 V5 A31
 V6 DATETIME23.2
 V7 DATETIME23.2
 V8 A66
 V9 A2
 V10 F4.0
 V11 A18
 V12 A20
 V13 A2
 V14 A2
 V15 A2
 V16 A2
 V17 A3
 V18 A3
 V19 A3
 V20 A3
 V21 A2
 V22 F1.0
 V23 F2.0
 V24 A2
 V25 F1.0
 V26 F2.0
 V27 A2
 V28 F1.0
 V29 F2.0
 V30 F2.0
 V31 F2.0
 V32 A2
 V33 A2
 V34 A2
 V35 A2
 V36 A2
 V37 A2
 V38 A2
 V39 A2
 V40 A2
 V41 A2
 V42 A2
 V43 A2
 V44 A2
 V45 A2
 V46 A2
 V47 A2
 V48 A2
 V49 A2
 V50 A2
 V51 A2
 V52 A2
 V53 A2
 V54 A2
 V55 A2
 V56 A2
 V57 A2
 V58 A2
 V59 A2
 V60 A2
 V61 A2
 V62 A2
 V63 A2
 V64 A2
 V65 A2
 V66 A2
 V67 A2.
CACHE.
EXECUTE.
*Define Variable Properties.
VARIABLE LABELS V1 "id".
VARIABLE LABELS V2 "submitdate".
VARIABLE LABELS V3 "lastpage".
VARIABLE LABELS V4 "startlanguage".
VARIABLE LABELS V5 "Seed".
VARIABLE LABELS V6 "startdate".
VARIABLE LABELS V7 "datestamp".
VARIABLE LABELS V8 "participantCode".
VARIABLE LABELS V9 "What gender do you identify with? ".
VARIABLE LABELS V10 "What is your birth year? ".
VARIABLE LABELS V11 "What is your Nationality? ".
VARIABLE LABELS V12 "In which country do you currently live?".
VARIABLE LABELS V13 "Do you currently study at a university or a university of applied sciences (HBO)?".
VARIABLE LABELS V14 "Please select which of the following options is most applicable to you".
VARIABLE LABELS V15 "How much money do you have available? ".
VARIABLE LABELS V16 "Which of the categories below do you self-identify with?".
VARIABLE LABELS V17 "[I foresee that I will have trouble sticking to my health goals in the future] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’"+
" and the value 10 means: ‘totally agree’   ".
VARIABLE LABELS V18 "[If I make a new year’s resolution for my health, I am sure that I will actually stick to it] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the value 1 means: ‘to"+
"tally disagree’ and the value 10 means: ‘totally agree’   ".
VARIABLE LABELS V19 "[I am the kind of person that needs extra commitment to stick to my health goals] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagr"+
"ee’ and the value 10 means: ‘totally agree’   ".
VARIABLE LABELS V20 "[How do you see yourself: are you generally a person who is fully prepared to take risks or do you try to avoid taking risks?] Please indicate to what extent you are willing to take risks in general. Please tick a box on the sca"+
"le, where the value 1 means: ‘not at all willing to take risks’ and the value 10 means: ‘very willing to take risks’   ".
VARIABLE LABELS V21 "We are interested in finding out about the kinds of physical activities that people do as part of their everyday lives. The next questions will ask you about the time you spent being physically active in the last 7 days. Please "+
"answer each question even if you do not consider yourself to be an active person. Please think about the activities you do at work, as part of your house and yard work, to get from place to place, and in your spare time for recr"+
"eation, exercise or sport.     Think about all the vigorous activities that you did in the last 7 days. Vigorous physical activities refer to activities that take hard physical effort and make you breathe much harder than normal"+
". Think only about those physical activities that you did for at least 10 minutes at a time.     During the last 7 days, on how many days did you do vigorous physical activities like heavy lifting, digging, aerobics, or fast bic"+
"ycling?".
VARIABLE LABELS V22 "[Hours per day] How much time did you usually spend doing vigorous physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for 'm"+
"inutes'.".
VARIABLE LABELS V23 "[Minutes per day] How much time did you usually spend doing vigorous physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for "+
"'minutes'.".
VARIABLE LABELS V24 "Think about all the moderate activities that you did in the last 7 days. Moderate activities refer to activities that take moderate physical effort and make you breathe somewhat harder than normal. Think only about those physica"+
"l activities that you did for at least 10 minutes at a time.     During the last 7 days, on how many days did you do moderate physical activities like carrying light loads, bicycling at a regular pace, or doubles tennis? Do not "+
"include walking.".
VARIABLE LABELS V25 "[Hours per day] How much time did you usually spend doing moderate physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for 'm"+
"inutes'.".
VARIABLE LABELS V26 "[Minutes per day] How much time did you usually spend doing moderate physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for "+
"'minutes'.".
VARIABLE LABELS V27 "Think about the time you spent walking in the last 7 days. This includes at work and at home, walking to travel from place to place, and any other walking that you have done solely for recreation, sport, exercise, or leisure.   "+
"  During the last 7 days, on how many days did you walk for at least 10 minutes at a time?".
VARIABLE LABELS V28 "[Hours per day] How much time did you usually spend walking on one of those days? As an example: if you did 1,5 hours of walking. Please fill in '1' in the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V29 "[Minutes per day] How much time did you usually spend walking on one of those days? As an example: if you did 1,5 hours of walking. Please fill in '1' in the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V30 "[Hours per day] The last question is about the time you spent sitting on weekdays during the last 7 days. Include time spent at work, at home, while doing course work and during leisure time. This may include time spent sitting "+
"at a desk, visiting friends, reading, or sitting or lying down to watch television.     During the last 7 days, how much time did you spend sitting on a week day? As an example: if you sat for 8,5 hours. Please fill in '8' in th"+
"e box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V31 "[Minutes per day] The last question is about the time you spent sitting on weekdays during the last 7 days. Include time spent at work, at home, while doing course work and during leisure time. This may include time spent sittin"+
"g at a desk, visiting friends, reading, or sitting or lying down to watch television.     During the last 7 days, how much time did you spend sitting on a week day? As an example: if you sat for 8,5 hours. Please fill in '8' in "+
"the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V32 "[I am confident that I can participate in regular exercise when I am tired] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select that opt"+
"ion   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V33 "[I am confident that I can participate in regular exercise when I am in a bad mood] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select "+
"that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V34 "[I am confident that I can participate in regular exercise when I feel I don’t have the time] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you c"+
"an select that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V35 "[I am confident that I can participate in regular exercise when I am on vacation] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select th"+
"at option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V36 "[I am confident that I can participate in regular exercise when it is raining or snowing.] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can "+
"select that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V37 "[If I wanted to go on a trip for a day (for example, to the country or mountains), I would have a hard time finding someone to go with me] Below you will find a list of statements each of which may or may not be true about you. "+
"For each statement select ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure t"+
"he statement is false and ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V38 "[I feel that there is no one I can share my most private worries and fears with] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are s"+
"ure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you think "+
"it is false but are not absolutely certain.      ".
VARIABLE LABELS V39 "[If I were sick, I could easily find someone to help me with my daily chores] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are sure"+
" it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you think it "+
"is false but are not absolutely certain.      ".
VARIABLE LABELS V40 "[There is someone I can turn to for advice about handling problems with my family] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are"+
" sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you thin"+
"k it is false but are not absolutely certain.      ".
VARIABLE LABELS V41 "[If I decide one afternoon that I would like to go to a movie that evening, I could easily find someone to go with me] Below you will find a list of statements each of which may or may not be true about you. For each statement s"+
"elect ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is fals"+
"e and ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V42 "[When I need suggestions on how to deal with a personal problem, I know someone I can turn to] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"+
"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"+
"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V43 "[I don't often get invited to do things with others] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are sure it is true about you and"+
" ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you think it is false but are not abso"+
"lutely certain.      ".
VARIABLE LABELS V44 "[If I had to go out of town for a few weeks, it would be difficult to find someone who would look after my house or apartment (the plants, pets, garden, etc.)] Below you will find a list of statements each of which may or may no"+
"t be true about you. For each statement select ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely fals"+
"e"" if you are sure the statement is false and ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V45 "[If I wanted to have lunch with someone, I could easily find someone to join me] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are s"+
"ure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you think "+
"it is false but are not absolutely certain.      ".
VARIABLE LABELS V46 "[If I was stranded 10 miles from home, there is someone I could call who could come and get me] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"+
""" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"+
""" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V47 "[If a family crisis arose, it would be difficult to find someone who could give me good advice about how to handle it] Below you will find a list of statements each of which may or may not be true about you. For each statement s"+
"elect ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is fals"+
"e and ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V48 "[If I needed some help in moving to a new house or apartment, I would have a hard time finding someone to help me] Below you will find a list of statements each of which may or may not be true about you. For each statement selec"+
"t ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false an"+
"d ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V49 "[Because I feel that I want to take responsibility for my own health ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements "+
"related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V50 "[Because I would feel guilty or ashamed of myself I did not do it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rela"+
"ted to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V51 "[Because I know I can earn rewards for doing it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving y"+
"our goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V52 "[Because I personally believe it is the best thing for my health ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rela"+
"ted to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V53 "[Because others would be upset with me if I did not do it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to a"+
"chieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V54 "[Because I want to earn as much rewards as possible] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achievi"+
"ng your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V55 "[Because I have carefully thought about it and believe being physically active is very important for many aspects of my life ] You are almost done. This is the final page with questions.     We want to know what drives you to be"+
" more physically active. Below you will find statements related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V56 "[Because I would feel bad about myself if I did not do it	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to "+
"achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V57 "[Because I would be angry at myself if I did not get the rewards] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements relat"+
"ed to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V58 "[Because being physically active is an important choice I really want to make ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find st"+
"atements related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V59 "[Because I feel pressure from others to do this] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving y"+
"our goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V60 "[Because I feel pressure from the rewards to do this] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achiev"+
"ing your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V61 "[Because being physically active is consistent with my life goals ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rel"+
"ated to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V62 "[Because I want others to approve of me 	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving your go"+
"als. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V63 "[Because I want to be proud of myself for earning the rewards	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related"+
" to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V64 "[Because it is very important to live as healthily as possible] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related"+
" to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V65 "[Because I want others to see I can do it ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving your g"+
"oals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V66 "[Because I want to earn rewards to show others I can do it	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to"+
" achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V67 "[Because being physically active would allow me to reduce my medication use] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find state"+
"ments related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
*Define Value labels.
VALUE LABELS  V9
 "A1" "Man"
 "A2" "Woman"
 "A3" "Other".
VALUE LABELS  V13
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V14
 "A1" "Working full-time"
 "A2" "Working part-time"
 "A3" "Student with a job"
 "A4" "Student without a job"
 "A5" "I don't want to answer this question".
VALUE LABELS  V15
 "A1" "More than my fellow students"
 "A2" "About the same as my fellow students"
 "A3" "Less than my fellow students"
 "A5" "I don't want to answer this question".
VALUE LABELS  V16
 "A1" "Underweight"
 "A2" "A bit underweight"
 "A3" "At an appropriate weight"
 "A4" "A bit overweight"
 "A5" "Overweight"
 "A6" "I don't want to answer this question".
VALUE LABELS  V17
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = Totally agree".
VALUE LABELS  V18
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = Totally agree".
VALUE LABELS  V19
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = Totally agree".
VALUE LABELS  V20
 "A1" "1 = Not at all willing to take risks"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = Very willing to take risks".
VALUE LABELS  V21
 "A0" "No vigorous physical activities"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V24
 "A0" "No moderate physical activities"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V27
 "A0" "No walking"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V32
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V33
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V34
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V35
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V36
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V37
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V38
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V39
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V40
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V41
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V42
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V43
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V44
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V45
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V46
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V47
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V48
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V49
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V50
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V51
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V52
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V53
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V54
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V55
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V56
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V57
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V58
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V59
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V60
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V61
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V62
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V63
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V64
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V65
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V66
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V67
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VARIABLE LEVEL V10(SCALE).
RENAME VARIABLE ( V1 = id ).
RENAME VARIABLE ( V2 = submitdate ).
RENAME VARIABLE ( V3 = lastpage ).
RENAME VARIABLE ( V4 = startlanguage ).
* Variable name was incorrect and was changed from  to q_ .
RENAME VARIABLE ( V5 = q_ ).
RENAME VARIABLE ( V6 = startdate ).
RENAME VARIABLE ( V7 = datestamp ).
RENAME VARIABLE ( V8 = participantCode ).
RENAME VARIABLE ( V9 = Q1 ).
RENAME VARIABLE ( V10 = Q2 ).
RENAME VARIABLE ( V11 = Q3 ).
RENAME VARIABLE ( V12 = Q4 ).
RENAME VARIABLE ( V13 = Q5 ).
RENAME VARIABLE ( V14 = Q6 ).
RENAME VARIABLE ( V15 = Q7 ).
RENAME VARIABLE ( V16 = Q8 ).
RENAME VARIABLE ( V17 = Q9_SQ1 ).
RENAME VARIABLE ( V18 = Q9_SQ2 ).
RENAME VARIABLE ( V19 = Q9_SQ3 ).
RENAME VARIABLE ( V20 = Q10_SQ1 ).
RENAME VARIABLE ( V21 = Q11 ).
RENAME VARIABLE ( V22 = Q12_SQ1 ).
RENAME VARIABLE ( V23 = Q12_SQ2 ).
RENAME VARIABLE ( V24 = Q13 ).
RENAME VARIABLE ( V25 = Q14_SQ1 ).
RENAME VARIABLE ( V26 = Q14_SQ2 ).
RENAME VARIABLE ( V27 = Q15 ).
RENAME VARIABLE ( V28 = Q16_SQ1 ).
RENAME VARIABLE ( V29 = Q16_SQ2 ).
RENAME VARIABLE ( V30 = Q17_SQ1 ).
RENAME VARIABLE ( V31 = Q17_SQ2 ).
RENAME VARIABLE ( V32 = Q18_SQ1 ).
RENAME VARIABLE ( V33 = Q18_SQ2 ).
RENAME VARIABLE ( V34 = Q18_SQ3 ).
RENAME VARIABLE ( V35 = Q18_SQ4 ).
RENAME VARIABLE ( V36 = Q18_SQ5 ).
RENAME VARIABLE ( V37 = Q19_SQ1 ).
RENAME VARIABLE ( V38 = Q19_SQ2 ).
RENAME VARIABLE ( V39 = Q19_SQ3 ).
RENAME VARIABLE ( V40 = Q19_SQ4 ).
RENAME VARIABLE ( V41 = Q19_SQ5 ).
RENAME VARIABLE ( V42 = Q19_SQ6 ).
RENAME VARIABLE ( V43 = Q19_SQ7 ).
RENAME VARIABLE ( V44 = Q19_SQ8 ).
RENAME VARIABLE ( V45 = Q19_SQ9 ).
RENAME VARIABLE ( V46 = Q19_SQ10 ).
RENAME VARIABLE ( V47 = Q19_SQ11 ).
RENAME VARIABLE ( V48 = Q19_SQ12 ).
RENAME VARIABLE ( V49 = Q20_SQ1 ).
RENAME VARIABLE ( V50 = Q20_SQ2 ).
RENAME VARIABLE ( V51 = Q20_SQ3 ).
RENAME VARIABLE ( V52 = Q20_SQ4 ).
RENAME VARIABLE ( V53 = Q20_SQ5 ).
RENAME VARIABLE ( V54 = Q20_SQ6 ).
RENAME VARIABLE ( V55 = Q20_SQ7 ).
RENAME VARIABLE ( V56 = Q20_SQ8 ).
RENAME VARIABLE ( V57 = Q20_SQ9 ).
RENAME VARIABLE ( V58 = Q20_SQ10 ).
RENAME VARIABLE ( V59 = Q20_SQ11 ).
RENAME VARIABLE ( V60 = Q20_SQ12 ).
RENAME VARIABLE ( V61 = Q20_SQ13 ).
RENAME VARIABLE ( V62 = Q20_SQ14 ).
RENAME VARIABLE ( V63 = Q20_SQ15 ).
RENAME VARIABLE ( V64 = Q20_SQ16 ).
RENAME VARIABLE ( V65 = Q20_SQ17 ).
RENAME VARIABLE ( V66 = Q20_SQ18 ).
RENAME VARIABLE ( V67 = Q20_SQ19 ).
RESTORE LOCALE.
