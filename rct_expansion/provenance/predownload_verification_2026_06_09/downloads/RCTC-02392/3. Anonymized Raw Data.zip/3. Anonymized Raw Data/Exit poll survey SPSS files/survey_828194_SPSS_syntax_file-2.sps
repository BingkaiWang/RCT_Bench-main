﻿*$Rev: 121017 $ complete 2.
SET UNICODE=ON.
SHOW LOCALE.
PRESERVE LOCALE.
SET LOCALE='en_UK'.
GET DATA
 /TYPE=TXT
 /FILE='survey_828194_SPSS_data_file.dat'
 /DELCASE=LINE
 /DELIMITERS=","
 /QUALIFIER="'"
 /ARRANGEMENT=DELIMITED
 /FIRSTCASE=1
 /IMPORTCASE=ALL
 /VARIABLES=
 V1 F7
 V2 DATETIME23.2
 V3 F7
 V4 A20
 V5 A31
 V6 DATETIME23.2
 V7 DATETIME23.2
 V8 A2
 V9 A2
 V10 F4.0
 V11 A10
 V12 A15
 V13 A2
 V14 A2
 V15 A2
 V16 A2
 V17 A3
 V18 A3
 V19 A3
 V20 A3
 V21 F1
 V22 F1
 V23 F1
 V24 A32
 V25 F1
 V26 F1
 V27 F1
 V28 F1
 V29 F1
 V30 F1
 V31 A1
 V32 A218
 V33 A2
 V34 F1.0
 V35 F2.0
 V36 A2
 V37 F1.0
 V38 F2.0
 V39 A2
 V40 F1.0
 V41 F2.0
 V42 F2.0
 V43 F2.0
 V44 A2
 V45 A2
 V46 A2
 V47 A2
 V48 A2
 V49 A2
 V50 A2
 V51 A2
 V52 A2
 V53 A2
 V54 A2
 V55 A2
 V56 A2
 V57 A2
 V58 A2
 V59 A2
 V60 A2
 V61 A2
 V62 A2
 V63 A2
 V64 A2
 V65 A2
 V66 A2
 V67 A2
 V68 A2
 V69 A2
 V70 A2
 V71 A2
 V72 A2
 V73 A2
 V74 A2
 V75 A2
 V76 A2
 V77 A2
 V78 A2
 V79 A2.
CACHE.
EXECUTE.
*Define Variable Properties.
VARIABLE LABELS V1 "id".
VARIABLE LABELS V2 "submitdate".
VARIABLE LABELS V3 "lastpage".
VARIABLE LABELS V4 "startlanguage".
VARIABLE LABELS V5 "Seed".
VARIABLE LABELS V6 "startdate".
VARIABLE LABELS V7 "datestamp".
VARIABLE LABELS V8 "Financial incentives for health behaviour change  You were interested in the BENEFIT MOVE Health intervention, completed the screening, and downloaded the application. Then, we noticed that you did not complete all of the steps n"+
"ecessary to participate in our research study.     Therefore, you are invited to participate in an online follow-up study to investigate factors that keep individuals from paying a deposit when used as a financial incentive to in"+
"crease physical activity. This is a research project being conducted by David de Buisonjé and Fiona Brosig at Leiden University.     Voluntary participation  Your participation in this research is voluntary. You may refuse to tak"+
"e part in the research or exit the study at any time without penalty. You are free to decline to answer any particular question you do not wish to answer for any reason.     What does the study entail?  You will be asked to fill "+
"in a short questionnaire that asks for information about you as an individual, your current physical activity and your motivation for improving your physical activity. Furthermore, the questionnaire contains questions about the r"+
"easons leading to decline payment of a deposit as a financial incentive to increase physical activity.      Duration  Filling in the questionnaire will approximately take 15-20 minutes of your time.       Reward for participation"+
"  All participants who complete this questionnaire will have a chance of winning one of three grand prizes worth € 100 (3 x Fitbit wearable device) and a chance to win one of 100 smaller prizes (100 x 10€ Bol.com vouchers). A max"+
"imum of 440 people will participate in this research, your odds of receiving a prize as remuneration will therefore be 1 in 5 or better.      Benefits  You will contribute to generating knowledge about financial incentives in con"+
"nection to physical activity, especially for deposit contracts. By generating this knowledge, we can increase our understanding of mechanisms contributing to the success or failure of deposit contracts. With that, we can help imp"+
"rove further research and interventions trying to improve people’s physical activity and health.     Confidentiality  Your survey answers will be sent to Limesurvey where data will be stored in a protected electronic format. We w"+
"ill collect your IP address to ensure unique participation. This information will not be used for any other purpose and will be removed directly after the study has finished. Based on the survey data, no one will be able to ident"+
"ify you or your answers, and no one will know whether or not you participated in the study. Based on the survey data, no one will be able to identify you or your answers, and no one will know whether or not you participated in th"+
"e study. If you choose to enter the raffle for one of the prizes we will ask for your name and e-mail address in a separate survey. Your contact details will not be stored together with the survey data, will only be used to infor"+
"m you of the raffle outcome and will be deleted directly after the study is finished. The data collected may be used for scientific publication but can never be traced back to you personally. The anonymous research data can be ac"+
"cessed by the principal investigator (Thomas Reijnders), the involved PhD-candidate (David de Buisonjé) and students working on their Bachelor thesis in this project.     Contact  If you have questions at any time about the study"+
" or the procedures, you may contact the conductor of this research, David de Buisonjé via email at d.r.de.buisonje@fsw.leidenuniv.nl. You may also contact the principal investigator of this study, Thomas Reijnders, via email at t"+
".reijnders@fsw.leidenuniv.nl or by phone: +31 71 527 2727. If you feel you have not been treated according to the descriptions in this form, or that your rights as a participant in research have not been honoured during the cours"+
"e of this project, or you have any questions, concerns, or complaints that you wish to address to someone other than the investigators, you may contact Dr. Veronica Janssen via email at vjanssen@fsw.leidenuniv.nl. You may also co"+
"ntact the privacy officer at the Faculty of Social sciences Drs Raymond van Erkel via email at r.van.erkel@fsw.leidenuniv.nl.      Please select your choice below. You may print a copy of this consent form for your records. Click"+
"ing on the “Agree” button indicates that:     - You have read the above information  - You voluntarily agree to participate  - You are 18 years of age or older  - You can read and understand the English language good enough to pa"+
"rticipate in this study".
VARIABLE LABELS V9 "What gender do you identify with? ".
VARIABLE LABELS V10 "What is your birth year? ".
VARIABLE LABELS V11 "What is your Nationality? ".
VARIABLE LABELS V12 "In which country do you currently live?".
VARIABLE LABELS V13 "Do you currently study at a university or a university of applied sciences (HBO)?".
VARIABLE LABELS V14 "Please select which of the following options is most applicable to you".
VARIABLE LABELS V15 "How much money do you have available? ".
VARIABLE LABELS V16 "Which of the categories below do you self-identify with?".
VARIABLE LABELS V17 "[I foresee that I will have trouble sticking to my health goals in the future] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagree’"+
" and the value 10 means: ‘totally agree’   ".
VARIABLE LABELS V18 "[If I make a new year’s resolution for my health, I am sure that I will actually stick to it] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the value 1 means: ‘to"+
"tally disagree’ and the value 10 means: ‘totally agree’   ".
VARIABLE LABELS V19 "[I am the kind of person that needs extra commitment to stick to my health goals] Please indicate to what extent you agree with the three statements below. Please tick a box on the scale, where the value 1 means: ‘totally disagr"+
"ee’ and the value 10 means: ‘totally agree’   ".
VARIABLE LABELS V20 "[How do you see yourself: are you generally a person who is fully prepared to take risks or do you try to avoid taking risks?] Please indicate to what extent you are willing to take risks in general. Please tick a box on the sca"+
"le, where the value 1 means: ‘not at all willing to take risks’ and the value 10 means: ‘very willing to take risks’   ".
VARIABLE LABELS V21 "[I wanted to be more physically active] Why did you want to participate in our study at first? (multiple answers possible)".
VARIABLE LABELS V22 "[I wanted to get a reward for my physical activity] Why did you want to participate in our study at first? (multiple answers possible)".
VARIABLE LABELS V23 "[I felt obligated to do it for the one who asked me to participate] Why did you want to participate in our study at first? (multiple answers possible)".
VARIABLE LABELS V24 "[Other] Why did you want to participate in our study at first? (multiple answers possible)".
VARIABLE LABELS V25 "[The deposit amount was too high] What was your reason to not continue with the study when you were asked for a deposit? (multiple answers possible)".
VARIABLE LABELS V26 "[The payment method did not work] What was your reason to not continue with the study when you were asked for a deposit? (multiple answers possible)".
VARIABLE LABELS V27 "[I did not want to risk losing my deposit] What was your reason to not continue with the study when you were asked for a deposit? (multiple answers possible)".
VARIABLE LABELS V28 "[The step goal was too high and I did not think I could make it] What was your reason to not continue with the study when you were asked for a deposit? (multiple answers possible)".
VARIABLE LABELS V29 "[The current Corona situation had an impact on my decision ] What was your reason to not continue with the study when you were asked for a deposit? (multiple answers possible)".
VARIABLE LABELS V30 "[Ethical/moral reasons (like objections to use money for motivation) ] What was your reason to not continue with the study when you were asked for a deposit? (multiple answers possible)".
VARIABLE LABELS V31 "[Other] What was your reason to not continue with the study when you were asked for a deposit? (multiple answers possible)".
VARIABLE LABELS V32 "Do you have any other comments? If so, you can add them in the box here:".
VARIABLE LABELS V33 "We are interested in finding out about the kinds of physical activities that people do as part of their everyday lives. The next questions will ask you about the time you spent being physically active in the last 7 days. Please "+
"answer each question even if you do not consider yourself to be an active person. Please think about the activities you do at work, as part of your house and yard work, to get from place to place, and in your spare time for recr"+
"eation, exercise or sport.     Think about all the vigorous activities that you did in the last 7 days. Vigorous physical activities refer to activities that take hard physical effort and make you breathe much harder than normal"+
". Think only about those physical activities that you did for at least 10 minutes at a time.     During the last 7 days, on how many days did you do vigorous physical activities like heavy lifting, digging, aerobics, or fast bic"+
"ycling?".
VARIABLE LABELS V34 "[Hours per day] How much time did you usually spend doing vigorous physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for 'm"+
"inutes'.".
VARIABLE LABELS V35 "[Minutes per day] How much time did you usually spend doing vigorous physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for "+
"'minutes'.".
VARIABLE LABELS V36 "Think about all the moderate activities that you did in the last 7 days. Moderate activities refer to activities that take moderate physical effort and make you breathe somewhat harder than normal. Think only about those physica"+
"l activities that you did for at least 10 minutes at a time.     During the last 7 days, on how many days did you do moderate physical activities like carrying light loads, bicycling at a regular pace, or doubles tennis? Do not "+
"include walking.".
VARIABLE LABELS V37 "[Hours per day] How much time did you usually spend doing moderate physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for 'm"+
"inutes'.".
VARIABLE LABELS V38 "[Minutes per day] How much time did you usually spend doing moderate physical activities on one  of those days? As an example: if you did 1,5 hours of exercise. Please fill in '1' in the box for 'hours', and '30' in the box for "+
"'minutes'.".
VARIABLE LABELS V39 "Think about the time you spent walking in the last 7 days. This includes at work and at home, walking to travel from place to place, and any other walking that you have done solely for recreation, sport, exercise, or leisure.   "+
"  During the last 7 days, on how many days did you walk for at least 10 minutes at a time?".
VARIABLE LABELS V40 "[Hours per day] How much time did you usually spend walking on one of those days? As an example: if you did 1,5 hours of walking. Please fill in '1' in the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V41 "[Minutes per day] How much time did you usually spend walking on one of those days? As an example: if you did 1,5 hours of walking. Please fill in '1' in the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V42 "[Hours per day] The last question is about the time you spent sitting on weekdays during the last 7 days. Include time spent at work, at home, while doing course work and during leisure time. This may include time spent sitting "+
"at a desk, visiting friends, reading, or sitting or lying down to watch television.     During the last 7 days, how much time did you spend sitting on a week day? As an example: if you sat for 8,5 hours. Please fill in '8' in th"+
"e box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V43 "[Minutes per day] The last question is about the time you spent sitting on weekdays during the last 7 days. Include time spent at work, at home, while doing course work and during leisure time. This may include time spent sittin"+
"g at a desk, visiting friends, reading, or sitting or lying down to watch television.     During the last 7 days, how much time did you spend sitting on a week day? As an example: if you sat for 8,5 hours. Please fill in '8' in "+
"the box for 'hours', and '30' in the box for 'minutes'.".
VARIABLE LABELS V44 "[I am confident that I can participate in regular exercise when I am tired] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select that opt"+
"ion   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V45 "[I am confident that I can participate in regular exercise when I am in a bad mood] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select "+
"that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V46 "[I am confident that I can participate in regular exercise when I feel I don’t have the time] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you c"+
"an select that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V47 "[I am confident that I can participate in regular exercise when I am on vacation] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can select th"+
"at option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V48 "[I am confident that I can participate in regular exercise when it is raining or snowing.] Please answer the following statements about your confidence in being able to exercise.  If the statement does not apply to you, you can "+
"select that option   Answering 1 means you are not confident at all  Answering 6 means you are very confident".
VARIABLE LABELS V49 "[If I wanted to go on a trip for a day (for example, to the country or mountains), I would have a hard time finding someone to go with me] Below you will find a list of statements each of which may or may not be true about you. "+
"For each statement select ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure t"+
"he statement is false and ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V50 "[I feel that there is no one I can share my most private worries and fears with] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are s"+
"ure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you think "+
"it is false but are not absolutely certain.      ".
VARIABLE LABELS V51 "[If I were sick, I could easily find someone to help me with my daily chores] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are sure"+
" it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you think it "+
"is false but are not absolutely certain.      ".
VARIABLE LABELS V52 "[There is someone I can turn to for advice about handling problems with my family] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are"+
" sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you thin"+
"k it is false but are not absolutely certain.      ".
VARIABLE LABELS V53 "[If I decide one afternoon that I would like to go to a movie that evening, I could easily find someone to go with me] Below you will find a list of statements each of which may or may not be true about you. For each statement s"+
"elect ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is fals"+
"e and ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V54 "[When I need suggestions on how to deal with a personal problem, I know someone I can turn to] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"+
"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"+
"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V55 "[I don't often get invited to do things with others] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are sure it is true about you and"+
" ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you think it is false but are not abso"+
"lutely certain.      ".
VARIABLE LABELS V56 "[If I had to go out of town for a few weeks, it would be difficult to find someone who would look after my house or apartment (the plants, pets, garden, etc.)] Below you will find a list of statements each of which may or may no"+
"t be true about you. For each statement select ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely fals"+
"e"" if you are sure the statement is false and ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V57 "[If I wanted to have lunch with someone, I could easily find someone to join me] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"" if you are s"+
"ure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"" if you think "+
"it is false but are not absolutely certain.      ".
VARIABLE LABELS V58 "[If I was stranded 10 miles from home, there is someone I could call who could come and get me] Below you will find a list of statements each of which may or may not be true about you. For each statement select ""definitely true"+
""" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false and ""probably false"+
""" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V59 "[If a family crisis arose, it would be difficult to find someone who could give me good advice about how to handle it] Below you will find a list of statements each of which may or may not be true about you. For each statement s"+
"elect ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is fals"+
"e and ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V60 "[If I needed some help in moving to a new house or apartment, I would have a hard time finding someone to help me] Below you will find a list of statements each of which may or may not be true about you. For each statement selec"+
"t ""definitely true"" if you are sure it is true about you and ""probably true"" if you think it is true but are not absolutely certain. Similarly, you should select ""definitely false"" if you are sure the statement is false an"+
"d ""probably false"" if you think it is false but are not absolutely certain.      ".
VARIABLE LABELS V61 "[Because I feel that I want to take responsibility for my own health ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements "+
"related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V62 "[Because I would feel guilty or ashamed of myself I did not do it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rela"+
"ted to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V63 "[Because I know I can earn rewards for doing it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving y"+
"our goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V64 "[Because I personally believe it is the best thing for my health ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rela"+
"ted to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V65 "[Because others would be upset with me if I did not do it] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to a"+
"chieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V66 "[Because I want to earn as much rewards as possible] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achievi"+
"ng your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V67 "[Because I have carefully thought about it and believe being physically active is very important for many aspects of my life ] You are almost done. This is the final page with questions.     We want to know what drives you to be"+
" more physically active. Below you will find statements related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V68 "[Because I would feel bad about myself if I did not do it	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to "+
"achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V69 "[Because I would be angry at myself if I did not get the rewards] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements relat"+
"ed to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V70 "[Because being physically active is an important choice I really want to make ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find st"+
"atements related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V71 "[Because I feel pressure from others to do this] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving y"+
"our goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V72 "[Because I feel pressure from the rewards to do this] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achiev"+
"ing your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V73 "[Because being physically active is consistent with my life goals ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements rel"+
"ated to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V74 "[Because I want others to approve of me 	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving your go"+
"als. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V75 "[Because I want to be proud of myself for earning the rewards	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related"+
" to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V76 "[Because it is very important to live as healthily as possible] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related"+
" to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V77 "[Because I want others to see I can do it ] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to achieving your g"+
"oals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V78 "[Because I want to earn rewards to show others I can do it	] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find statements related to"+
" achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
VARIABLE LABELS V79 "[Because being physically active would allow me to reduce my medication use] You are almost done. This is the final page with questions.     We want to know what drives you to be more physically active. Below you will find state"+
"ments related to achieving your goals. To what extent do you agree with the following statements?      I want to be more physically active because….".
*Define Value labels.
VALUE LABELS  V8
 "A1" "Agree"
 "A2" "Disagree".
VALUE LABELS  V9
 "A1" "Man"
 "A2" "Woman"
 "A3" "Other".
VALUE LABELS  V13
 "A1" "Yes"
 "A2" "No".
VALUE LABELS  V14
 "A1" "Working full-time"
 "A2" "Working part-time"
 "A3" "Student with a job"
 "A4" "Student without a job"
 "A5" "I don't want to answer this question".
VALUE LABELS  V15
 "A1" "More than my fellow students"
 "A2" "About the same as my fellow students"
 "A3" "Less than my fellow students"
 "A5" "I don't want to answer this question".
VALUE LABELS  V16
 "A1" "Underweight"
 "A2" "A bit underweight"
 "A3" "At an appropriate weight"
 "A4" "A bit overweight"
 "A5" "Overweight"
 "A6" "I don't want to answer this question".
VALUE LABELS  V17
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = Totally agree".
VALUE LABELS  V18
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = Totally agree".
VALUE LABELS  V19
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = Totally agree".
VALUE LABELS  V20
 "A1" "1 = Not at all willing to take risks"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7"
 "A8" "8"
 "A9" "9"
 "A10" "10 = Very willing to take risks".
VALUE LABELS  V21
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V22
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V23
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V25
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V26
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V27
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V28
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V29
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V30
 1 "Yes"
 0 "Not selected".
VALUE LABELS  V33
 "A0" "No vigorous physical activities"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V36
 "A0" "No moderate physical activities"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V39
 "A0" "No walking"
 "A1" "1 day"
 "A2" "2 days"
 "A3" "3 days"
 "A4" "4 days"
 "A5" "5 days"
 "A6" "6 days"
 "A7" "7 days".
VALUE LABELS  V44
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V45
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V46
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V47
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V48
 "A0" "This does not apply to me"
 "A1" "1= Not confident at all"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6 = Very confident".
VALUE LABELS  V49
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V50
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V51
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V52
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V53
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V54
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V55
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V56
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V57
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V58
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V59
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V60
 "A1" "1 = Definitely false"
 "A2" "2 = Probably false"
 "A3" "3 = Probably true"
 "A4" "4 = Definitely true".
VALUE LABELS  V61
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V62
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V63
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V64
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V65
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V66
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V67
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V68
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V69
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V70
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V71
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V72
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V73
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V74
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V75
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V76
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V77
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V78
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VALUE LABELS  V79
 "A1" "1 = Totally disagree"
 "A2" "2"
 "A3" "3"
 "A4" "4"
 "A5" "5"
 "A6" "6"
 "A7" "7 = Totally agree".
VARIABLE LEVEL V10(SCALE).
RENAME VARIABLE ( V1 = id ).
RENAME VARIABLE ( V2 = submitdate ).
RENAME VARIABLE ( V3 = lastpage ).
RENAME VARIABLE ( V4 = startlanguage ).
* Variable name was incorrect and was changed from  to q_ .
RENAME VARIABLE ( V5 = q_ ).
RENAME VARIABLE ( V6 = startdate ).
RENAME VARIABLE ( V7 = datestamp ).
RENAME VARIABLE ( V8 = Q25 ).
RENAME VARIABLE ( V9 = Q1 ).
RENAME VARIABLE ( V10 = Q2 ).
RENAME VARIABLE ( V11 = Q3 ).
RENAME VARIABLE ( V12 = Q4 ).
RENAME VARIABLE ( V13 = Q5 ).
RENAME VARIABLE ( V14 = Q6 ).
RENAME VARIABLE ( V15 = Q7 ).
RENAME VARIABLE ( V16 = Q8 ).
RENAME VARIABLE ( V17 = Q9_SQ1 ).
RENAME VARIABLE ( V18 = Q9_SQ2 ).
RENAME VARIABLE ( V19 = Q9_SQ3 ).
RENAME VARIABLE ( V20 = Q10_SQ1 ).
RENAME VARIABLE ( V21 = Q21_A1 ).
RENAME VARIABLE ( V22 = Q21_A2 ).
RENAME VARIABLE ( V23 = Q21_A3 ).
RENAME VARIABLE ( V24 = Q21_other ).
RENAME VARIABLE ( V25 = Q22_A1 ).
RENAME VARIABLE ( V26 = Q22_A2 ).
RENAME VARIABLE ( V27 = Q22_A3 ).
RENAME VARIABLE ( V28 = Q22_A4 ).
RENAME VARIABLE ( V29 = Q22_A5 ).
RENAME VARIABLE ( V30 = Q22_A6 ).
RENAME VARIABLE ( V31 = Q22_other ).
RENAME VARIABLE ( V32 = Q23 ).
RENAME VARIABLE ( V33 = Q11 ).
RENAME VARIABLE ( V34 = Q12_SQ1 ).
RENAME VARIABLE ( V35 = Q12_SQ2 ).
RENAME VARIABLE ( V36 = Q13 ).
RENAME VARIABLE ( V37 = Q14_SQ1 ).
RENAME VARIABLE ( V38 = Q14_SQ2 ).
RENAME VARIABLE ( V39 = Q15 ).
RENAME VARIABLE ( V40 = Q16_SQ1 ).
RENAME VARIABLE ( V41 = Q16_SQ2 ).
RENAME VARIABLE ( V42 = Q17_SQ1 ).
RENAME VARIABLE ( V43 = Q17_SQ2 ).
RENAME VARIABLE ( V44 = Q18_SQ1 ).
RENAME VARIABLE ( V45 = Q18_SQ2 ).
RENAME VARIABLE ( V46 = Q18_SQ3 ).
RENAME VARIABLE ( V47 = Q18_SQ4 ).
RENAME VARIABLE ( V48 = Q18_SQ5 ).
RENAME VARIABLE ( V49 = Q19_SQ1 ).
RENAME VARIABLE ( V50 = Q19_SQ2 ).
RENAME VARIABLE ( V51 = Q19_SQ3 ).
RENAME VARIABLE ( V52 = Q19_SQ4 ).
RENAME VARIABLE ( V53 = Q19_SQ5 ).
RENAME VARIABLE ( V54 = Q19_SQ6 ).
RENAME VARIABLE ( V55 = Q19_SQ7 ).
RENAME VARIABLE ( V56 = Q19_SQ8 ).
RENAME VARIABLE ( V57 = Q19_SQ9 ).
RENAME VARIABLE ( V58 = Q19_SQ10 ).
RENAME VARIABLE ( V59 = Q19_SQ11 ).
RENAME VARIABLE ( V60 = Q19_SQ12 ).
RENAME VARIABLE ( V61 = Q20_SQ1 ).
RENAME VARIABLE ( V62 = Q20_SQ2 ).
RENAME VARIABLE ( V63 = Q20_SQ3 ).
RENAME VARIABLE ( V64 = Q20_SQ4 ).
RENAME VARIABLE ( V65 = Q20_SQ5 ).
RENAME VARIABLE ( V66 = Q20_SQ6 ).
RENAME VARIABLE ( V67 = Q20_SQ7 ).
RENAME VARIABLE ( V68 = Q20_SQ8 ).
RENAME VARIABLE ( V69 = Q20_SQ9 ).
RENAME VARIABLE ( V70 = Q20_SQ10 ).
RENAME VARIABLE ( V71 = Q20_SQ11 ).
RENAME VARIABLE ( V72 = Q20_SQ12 ).
RENAME VARIABLE ( V73 = Q20_SQ13 ).
RENAME VARIABLE ( V74 = Q20_SQ14 ).
RENAME VARIABLE ( V75 = Q20_SQ15 ).
RENAME VARIABLE ( V76 = Q20_SQ16 ).
RENAME VARIABLE ( V77 = Q20_SQ17 ).
RENAME VARIABLE ( V78 = Q20_SQ18 ).
RENAME VARIABLE ( V79 = Q20_SQ19 ).
RESTORE LOCALE.
